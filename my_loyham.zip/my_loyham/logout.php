<?php
session_start();
session_destroy();
header('Location: project10.php');
exit;
?>
