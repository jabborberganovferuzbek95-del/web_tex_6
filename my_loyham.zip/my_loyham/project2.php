<?php

// ===== PHP SERVER-SIDE LOGIC =====

$errors   = [];
$formData = [];
$yosh     = null;
$success  = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // 1. ISM
    $ism = trim($_POST['ism'] ?? '');
    if (empty($ism)) {
        $errors['ism'] = 'Ism kiritilishi shart!';
    } elseif (strlen($ism) < 2) {
        $errors['ism'] = 'Ism kamida 2 ta harf bo\'lishi kerak!';
    } else {
        $formData['ism'] = htmlspecialchars($ism);
    }

    // 2. FAMILIYA
    $familiya = trim($_POST['familiya'] ?? '');
    if (empty($familiya)) {
        $errors['familiya'] = 'Familiya kiritilishi shart!';
    } elseif (strlen($familiya) < 2) {
        $errors['familiya'] = 'Familiya kamida 2 ta harf bo\'lishi kerak!';
    } else {
        $formData['familiya'] = htmlspecialchars($familiya);
    }

    // 3. TUG'ILGAN SANA + YOSH HISOBLASH
    $sana = trim($_POST['tugilgan_sana'] ?? '');
    if (empty($sana)) {
        $errors['tugilgan_sana'] = 'Tug\'ilgan sana kiritilishi shart!';
    } else {
        $tugilgan = DateTime::createFromFormat('Y-m-d', $sana);
        if (!$tugilgan) {
            $errors['tugilgan_sana'] = 'Sana formati noto\'g\'ri!';
        } else {
            $bugun = new DateTime();
            if ($tugilgan > $bugun) {
                $errors['tugilgan_sana'] = 'Tug\'ilgan sana kelajakda bo\'lishi mumkin emas!';
            } else {
                $interval = $bugun->diff($tugilgan);
                $yosh = $interval->y;
                $formData['tugilgan_sana'] = htmlspecialchars($sana);
            }
        }
    }

    // 4. EMAIL
    $email = trim($_POST['email'] ?? '');
    if (empty($email)) {
        $errors['email'] = 'Email kiritilishi shart!';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = 'Email formati noto\'g\'ri! (masalan: mail@example.com)';
    } else {
        $formData['email'] = htmlspecialchars($email);
    }

    // 5. TELEFON
    $telefon = trim($_POST['telefon'] ?? '');
    $telefonClean = preg_replace('/\s+/', '', $telefon);
    if (empty($telefon)) {
        $errors['telefon'] = 'Telefon raqami kiritilishi shart!';
    } elseif (!preg_match('/^(\+998|998|0)?[0-9]{9}$/', $telefonClean)) {
        $errors['telefon'] = 'Telefon raqami noto\'g\'ri! (masalan: +998901234567)';
    } else {
        $formData['telefon'] = htmlspecialchars($telefon);
    }

    if (empty($errors)) {
        $success = true;
        // Bu yerda ma'lumotlarni DB ga saqlash mumkin:
        // saveToDB($formData, $yosh);
    }
}

// Helper: field value qaytarish (xatolikdan keyin formni saqlab qolish)
function old(string $field): string {
    return htmlspecialchars($_POST[$field] ?? '');
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Anketa To'ldirish – PHP</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #4CAF50;
            --primary-dark: #45a049;
            --secondary-color: #2196F3;
            --success-color: #2e7d32;
            --danger-color: #f44336;
            --warning-bg: #fff3e0;
            --bg-primary: #f8fbff;
            --bg-secondary: #ffffff;
            --text-primary: #2c3e50;
            --text-secondary: #555;
            --border-color: #e0e6ed;
            --shadow: 0 20px 40px rgba(0,0,0,0.1);
            --glass-bg: rgba(255,255,255,0.95);
            --glass-border: rgba(255,255,255,0.25);
        }

        [data-theme="dark"] {
            --bg-primary: #1a1f2e;
            --bg-secondary: #16213e;
            --text-primary: #ecf0f1;
            --text-secondary: #bdc3c7;
            --border-color: #34495e;
            --glass-bg: rgba(26, 31, 46, 0.95);
            --shadow: 0 20px 40px rgba(0,0,0,0.3);
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            font-family: 'Roboto', sans-serif;
            background: linear-gradient(135deg, var(--bg-primary) 0%, #e3f2fd 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
            transition: all 0.3s ease;
            position: relative;
            overflow-x: hidden;
        }

        body::before {
            content: '';
            position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background:
                radial-gradient(circle at 20% 80%, rgba(120,119,198,0.3) 0%, transparent 50%),
                radial-gradient(circle at 80% 20%, rgba(255,119,198,0.3) 0%, transparent 50%),
                radial-gradient(circle at 40% 40%, rgba(120,219,255,0.3) 0%, transparent 50%);
            pointer-events: none; z-index: -1;
        }

        .container {
            background: var(--glass-bg);
            backdrop-filter: blur(20px);
            border: 1px solid var(--glass-border);
            padding: 40px;
            border-radius: 24px;
            box-shadow: var(--shadow);
            width: 100%;
            max-width: 500px;
            position: relative;
            animation: slideUp 0.6s cubic-bezier(0.25, 0.46, 0.45, 0.94);
        }

        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to   { opacity: 1; transform: translateY(0); }
        }

        .theme-toggle {
            position: absolute; top: 20px; right: 20px;
            background: transparent; border: none;
            font-size: 20px; cursor: pointer;
            color: var(--text-secondary); transition: all 0.3s ease;
        }
        .theme-toggle:hover { color: var(--primary-color); transform: rotate(20deg); }

        .header-wrapper { text-align: center; margin-bottom: 35px; }

        h2 {
            color: var(--text-primary);
            font-weight: 700; font-size: 28px; margin-bottom: 10px;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        /* PHP badge */
        .php-badge {
            display: inline-block;
            background: linear-gradient(135deg, #8993be, #4f5b93);
            color: white; font-size: 11px; font-weight: 700;
            padding: 3px 10px; border-radius: 20px;
            letter-spacing: 1px; margin-top: 6px;
            box-shadow: 0 3px 10px rgba(79,91,147,0.4);
        }

        /* Error summary */
        .error-summary {
            background: #fdecea;
            border: 2px solid #f44336;
            border-radius: 14px;
            padding: 16px 20px;
            margin-bottom: 20px;
            animation: shake 0.4s ease;
        }
        .error-summary h4 { color: #c62828; margin-bottom: 8px; font-size: 14px; }
        .error-summary ul { padding-left: 18px; }
        .error-summary li { color: #c62828; font-size: 13px; margin-bottom: 4px; }

        /* Success banner */
        .success-banner {
            background: linear-gradient(135deg, #e8f5e9, #c8e6c9);
            border: 2px solid rgba(76,175,80,0.4);
            border-radius: 20px;
            padding: 30px;
            animation: slideDown 0.5s cubic-bezier(0.25, 0.46, 0.45, 0.94);
            position: relative;
            margin-bottom: 25px;
        }
        .success-banner h3 {
            color: var(--success-color);
            text-align: center; margin-bottom: 20px;
            font-size: 18px;
        }
        .success-icon {
            position: absolute; top: -15px; right: -15px;
            width: 40px; height: 40px;
            background: var(--primary-color); border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            color: white; font-size: 18px;
            box-shadow: 0 8px 20px rgba(76,175,80,0.4);
        }

        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-20px) scale(0.95); }
            to   { opacity: 1; transform: translateY(0) scale(1); }
        }
        @keyframes shake {
            0%,100% { transform: translateX(0); }
            25%      { transform: translateX(-5px); }
            75%      { transform: translateX(5px); }
        }

        .result-item {
            display: flex; align-items: center; gap: 10px;
            margin-bottom: 12px; padding: 12px 16px;
            background: rgba(255,255,255,0.75);
            border-radius: 12px; border-left: 4px solid var(--primary-color);
            transition: all 0.3s ease;
        }
        .result-item:hover { transform: translateX(5px); box-shadow: 0 5px 15px rgba(0,0,0,0.1); }
        .result-item strong { color: var(--success-color); min-width: 140px; font-weight: 600; }
        .result-item span { color: var(--text-primary); }

        /* Form */
        .form-group { margin-bottom: 20px; position: relative; }

        label {
            display: block; margin-bottom: 7px;
            color: var(--text-primary); font-weight: 500; font-size: 14px;
        }

        .input-wrapper { position: relative; }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="date"] {
            width: 100%; padding: 15px 48px 15px 18px;
            border: 2px solid var(--border-color);
            border-radius: 14px; font-size: 16px;
            background: rgba(255,255,255,0.85);
            transition: all 0.3s ease; font-family: inherit;
            color: var(--text-primary);
        }

        input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 4px rgba(76,175,80,0.12);
            background: #fff;
            transform: translateY(-2px);
        }

        input.field-valid   { border-color: var(--success-color); box-shadow: 0 0 0 4px rgba(46,125,50,0.1); }
        input.field-invalid { border-color: var(--danger-color);  box-shadow: 0 0 0 4px rgba(244,67,54,0.1); animation: shake 0.4s ease; }

        .field-icon {
            position: absolute; right: 16px; top: 50%;
            transform: translateY(-50%); font-size: 17px;
            color: var(--text-secondary); pointer-events: none;
            transition: color 0.3s;
        }
        input.field-valid   ~ .field-icon { color: var(--success-color); }
        input.field-invalid ~ .field-icon { color: var(--danger-color); }

        .field-error {
            color: var(--danger-color); font-size: 12px;
            margin-top: 5px; display: flex; align-items: center; gap: 5px;
        }

        button[type="submit"] {
            width: 100%; padding: 17px;
            background: linear-gradient(135deg, var(--primary-color), var(--primary-dark));
            color: white; border: none; border-radius: 16px;
            font-size: 16px; font-weight: 600; cursor: pointer;
            margin-top: 8px; position: relative; overflow: hidden;
            transition: all 0.3s ease; text-transform: uppercase; letter-spacing: 1px;
        }
        button[type="submit"]::before {
            content: ''; position: absolute; top: 0; left: -100%;
            width: 100%; height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.28), transparent);
            transition: left 0.5s;
        }
        button[type="submit"]:hover::before { left: 100%; }
        button[type="submit"]:hover { transform: translateY(-3px); box-shadow: 0 15px 30px rgba(76,175,80,0.3); }

        .new-btn {
            display: block; width: 100%; padding: 13px;
            background: transparent; border: 2px solid var(--primary-color);
            color: var(--primary-color); border-radius: 16px; font-size: 15px;
            font-weight: 600; cursor: pointer; text-align: center;
            transition: all 0.3s ease; text-decoration: none; margin-top: 12px;
        }
        .new-btn:hover { background: var(--primary-color); color: white; transform: translateY(-2px); }

        .copy-btn {
            display: flex; align-items: center; justify-content: center; gap: 8px;
            width: 100%; padding: 11px;
            background: var(--secondary-color); color: white; border: none;
            border-radius: 25px; cursor: pointer; font-size: 14px;
            margin-top: 18px; transition: all 0.3s ease;
        }
        .copy-btn:hover { background: #1976d2; transform: translateY(-2px); }

        /* PHP info box */
        .php-info {
            background: linear-gradient(135deg, #f3e5f5, #e8eaf6);
            border-left: 4px solid #7b1fa2;
            border-radius: 12px; padding: 14px 18px;
            margin-top: 20px; font-size: 13px;
            color: #4a148c;
        }
        .php-info strong { display: block; margin-bottom: 6px; }
        .php-info code {
            background: rgba(123,31,162,0.1); padding: 2px 7px;
            border-radius: 5px; font-family: monospace; font-size: 12px;
        }

        @media (max-width: 480px) {
            .container { padding: 28px 20px; }
            h2 { font-size: 22px; }
        }
    </style>
</head>
<body>

<div class="container">

    <button class="theme-toggle" id="themeToggle" title="Mavzuni o'zgartirish">
        <i class="fas fa-moon"></i>
    </button>

    <div class="header-wrapper">
        <h2><i class="fas fa-user-plus"></i> Anketa To'ldirish</h2>
        <span class="php-badge"><i class="fab fa-php"></i> PHP Backend</span>
    </div>

    <?php if ($success): ?>
    <!-- ===== MUVAFFAQIYATLI NATIJA ===== -->
    <div class="success-banner" id="resultBox">
        <div class="success-icon"><i class="fas fa-check"></i></div>
        <h3><i class="fas fa-check-circle"></i> Ma'lumotlar muvaffaqiyatli qabul qilindi!</h3>

        <div class="result-item">
            <strong><i class="fas fa-user"></i> Ism:</strong>
            <span><?= $formData['ism'] ?></span>
        </div>
        <div class="result-item">
            <strong><i class="fas fa-users"></i> Familiya:</strong>
            <span><?= $formData['familiya'] ?></span>
        </div>
        <div class="result-item">
            <strong><i class="fas fa-calendar-alt"></i> Tug'ilgan sana:</strong>
            <span><?= $formData['tugilgan_sana'] ?></span>
        </div>
        <div class="result-item">
            <strong><i class="fas fa-birthday-cake"></i> Yoshi:</strong>
            <span><?= $yosh ?> yosh</span>
        </div>
        <div class="result-item">
            <strong><i class="fas fa-envelope"></i> Email:</strong>
            <span><?= $formData['email'] ?></span>
        </div>
        <div class="result-item">
            <strong><i class="fas fa-phone"></i> Telefon:</strong>
            <span><?= $formData['telefon'] ?></span>
        </div>

        <button class="copy-btn" id="copyBtn">
            <i class="fas fa-copy"></i> Nusxalash
        </button>
    </div>

    <a href="<?= $_SERVER['PHP_SELF'] ?>" class="new-btn">
        <i class="fas fa-redo"></i> Yangi anketa to'ldirish
    </a>

    <?php else: ?>
    <!-- ===== FORMA ===== -->

    <?php if (!empty($errors)): ?>
    <div class="error-summary">
        <h4><i class="fas fa-exclamation-triangle"></i> Quyidagi xatolarni tuzating:</h4>
        <ul>
            <?php foreach ($errors as $err): ?>
                <li><?= $err ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
    <?php endif; ?>

    <form method="POST" action="<?= $_SERVER['PHP_SELF'] ?>" id="myForm" novalidate>

        <!-- ISM -->
        <div class="form-group">
            <label for="ism"><i class="fas fa-user"></i> Ism:</label>
            <div class="input-wrapper">
                <input
                    type="text"
                    id="ism"
                    name="ism"
                    placeholder="Ismingizni kiriting..."
                    value="<?= old('ism') ?>"
                    class="<?= isset($errors['ism']) ? 'field-invalid' : (old('ism') !== '' ? 'field-valid' : '') ?>"
                    required>
                <i class="fas fa-check-circle field-icon"></i>
            </div>
            <?php if (isset($errors['ism'])): ?>
                <div class="field-error"><i class="fas fa-exclamation-circle"></i> <?= $errors['ism'] ?></div>
            <?php endif; ?>
        </div>

        <!-- FAMILIYA -->
        <div class="form-group">
            <label for="familiya"><i class="fas fa-users"></i> Familiya:</label>
            <div class="input-wrapper">
                <input
                    type="text"
                    id="familiya"
                    name="familiya"
                    placeholder="Familiyangizni kiriting..."
                    value="<?= old('familiya') ?>"
                    class="<?= isset($errors['familiya']) ? 'field-invalid' : (old('familiya') !== '' ? 'field-valid' : '') ?>"
                    required>
                <i class="fas fa-check-circle field-icon"></i>
            </div>
            <?php if (isset($errors['familiya'])): ?>
                <div class="field-error"><i class="fas fa-exclamation-circle"></i> <?= $errors['familiya'] ?></div>
            <?php endif; ?>
        </div>

        <!-- TUG'ILGAN SANA -->
        <div class="form-group">
            <label for="tugilgan_sana"><i class="fas fa-calendar-alt"></i> Tug'ilgan sana:</label>
            <div class="input-wrapper">
                <input
                    type="date"
                    id="tugilgan_sana"
                    name="tugilgan_sana"
                    value="<?= old('tugilgan_sana') ?>"
                    max="<?= date('Y-m-d') ?>"
                    class="<?= isset($errors['tugilgan_sana']) ? 'field-invalid' : (old('tugilgan_sana') !== '' ? 'field-valid' : '') ?>"
                    required>
                <i class="fas fa-check-circle field-icon"></i>
            </div>
            <?php if (isset($errors['tugilgan_sana'])): ?>
                <div class="field-error"><i class="fas fa-exclamation-circle"></i> <?= $errors['tugilgan_sana'] ?></div>
            <?php endif; ?>
        </div>

        <!-- EMAIL -->
        <div class="form-group">
            <label for="email"><i class="fas fa-envelope"></i> Email:</label>
            <div class="input-wrapper">
                <input
                    type="email"
                    id="email"
                    name="email"
                    placeholder="mail@example.com"
                    value="<?= old('email') ?>"
                    class="<?= isset($errors['email']) ? 'field-invalid' : (old('email') !== '' ? 'field-valid' : '') ?>"
                    required>
                <i class="fas fa-check-circle field-icon"></i>
            </div>
            <?php if (isset($errors['email'])): ?>
                <div class="field-error"><i class="fas fa-exclamation-circle"></i> <?= $errors['email'] ?></div>
            <?php endif; ?>
        </div>

        <!-- TELEFON -->
        <div class="form-group">
            <label for="telefon"><i class="fas fa-phone"></i> Telefon:</label>
            <div class="input-wrapper">
                <input
                    type="tel"
                    id="telefon"
                    name="telefon"
                    placeholder="+998 90 123 45 67"
                    value="<?= old('telefon') ?>"
                    class="<?= isset($errors['telefon']) ? 'field-invalid' : (old('telefon') !== '' ? 'field-valid' : '') ?>"
                    required>
                <i class="fas fa-check-circle field-icon"></i>
            </div>
            <?php if (isset($errors['telefon'])): ?>
                <div class="field-error"><i class="fas fa-exclamation-circle"></i> <?= $errors['telefon'] ?></div>
            <?php endif; ?>
        </div>

        <button type="submit">
            <i class="fas fa-paper-plane"></i> Natijani ko'rish
        </button>

    </form>

    <div class="php-info">
        <strong><i class="fab fa-php"></i> PHP Validation qoidalari:</strong>
        Ism/Familiya: <code>strlen ≥ 2</code> &nbsp;|&nbsp;
        Email: <code>FILTER_VALIDATE_EMAIL</code> &nbsp;|&nbsp;
        Telefon: <code>+998XXXXXXXXX</code> &nbsp;|&nbsp;
        Yosh: <code>DateTime::diff()</code>
    </div>

    <?php endif; ?>

</div>

<script>
    // ===== CLIENT-SIDE JS (Dark mode + real-time validation + copy) =====

    const themeToggle = document.getElementById('themeToggle');

    // Saqlangan mavzuni yuklash
    const savedTheme = localStorage.getItem('theme') || 'light';
    document.body.setAttribute('data-theme', savedTheme);
    if (savedTheme === 'dark') themeToggle.querySelector('i').className = 'fas fa-sun';

    themeToggle.addEventListener('click', () => {
        const cur = document.body.getAttribute('data-theme');
        const next = cur === 'dark' ? 'light' : 'dark';
        document.body.setAttribute('data-theme', next);
        themeToggle.querySelector('i').className = next === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
        localStorage.setItem('theme', next);
    });

    // Real-time client validation (JS — PHP server-side asosiy)
    const inputs = document.querySelectorAll('input');

    function validateField(input) {
        const val = input.value.trim();
        input.classList.remove('field-valid', 'field-invalid');

        if (!val) { input.classList.add('field-invalid'); return false; }

        if (input.type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val)) {
            input.classList.add('field-invalid'); return false;
        }
        if (input.id === 'telefon' && !/^(\+998|998|0)?[0-9]{9}$/.test(val.replace(/\s/g,''))) {
            input.classList.add('field-invalid'); return false;
        }
        if ((input.id === 'ism' || input.id === 'familiya') && val.length < 2) {
            input.classList.add('field-invalid'); return false;
        }

        input.classList.add('field-valid');
        return true;
    }

    inputs.forEach(inp => {
        inp.addEventListener('input', () => validateField(inp));
        inp.addEventListener('blur',  () => validateField(inp));
    });

    // Nusxalash tugmasi
    const copyBtn = document.getElementById('copyBtn');
    if (copyBtn) {
        copyBtn.addEventListener('click', () => {
            const text = document.getElementById('resultBox').innerText;
            navigator.clipboard.writeText(text).then(() => {
                copyBtn.innerHTML = '<i class="fas fa-check"></i> Nusxalandi!';
                copyBtn.style.background = '#2e7d32';
                setTimeout(() => {
                    copyBtn.innerHTML = '<i class="fas fa-copy"></i> Nusxalash';
                    copyBtn.style.background = '';
                }, 2500);
            });
        });
    }
</script>

</body>
</html>