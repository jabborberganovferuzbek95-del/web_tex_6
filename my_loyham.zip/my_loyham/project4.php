<?php
require_once __DIR__ . '/db.php';

$pdo = getConnection();

// ── INNER JOIN so'rovi ───────────────────────────────────────────────────────
$sql = "
    SELECT
        o.ism                        AS oyinchi,
        o.pozitsiya                  AS pozitsiya,
        j.nomi                       AS jamoa,
        j.shahar                     AS shahar,
        j.rang                       AS rang,
        oy.sana                      AS sana,
        oy.raqib                     AS raqib,
        oy.natija                    AS natija
    FROM       oyinchilar  o
    INNER JOIN jamoalar    j   ON o.jamoa_id  = j.id
    INNER JOIN oyinlar     oy  ON oy.jamoa_id = j.id
    ORDER BY   oy.sana DESC, j.nomi, o.ism
";

$stmt    = $pdo->query($sql);
$qatorlar = $stmt->fetchAll();

// ── Statistika ──────────────────────────────────────────────────────────────
$statSql = "
    SELECT
        j.nomi,
        j.rang,
        COUNT(DISTINCT o.id)  AS oyinchilar_soni,
        COUNT(DISTINCT oy.id) AS oyinlar_soni
    FROM       jamoalar   j
    LEFT JOIN  oyinchilar o  ON o.jamoa_id  = j.id
    LEFT JOIN  oyinlar    oy ON oy.jamoa_id = j.id
    GROUP BY   j.id
    ORDER BY   oyinchilar_soni DESC
";
$stats = $pdo->query($statSql)->fetchAll();
?>
<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>⚽ Futbol Klubi — db_futbol</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;700&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
<style>
/* ── Reset & Root ── */
*, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

:root {
    --pitch:   #0a1628;
    --surface: #0f1f3d;
    --card:    #142240;
    --border:  rgba(255,255,255,0.07);
    --accent:  #00e676;
    --yellow:  #ffea00;
    --text:    #e8edf5;
    --muted:   #6b82a8;
    --radius:  12px;
    --mono:    'JetBrains Mono', monospace;
}

html { scroll-behavior: smooth; }

body {
    background: var(--pitch);
    color: var(--text);
    font-family: 'DM Sans', sans-serif;
    min-height: 100vh;
    overflow-x: hidden;
}

/* ── Background texture ── */
body::before {
    content: '';
    position: fixed; inset: 0;
    background:
        radial-gradient(ellipse 80% 60% at 20% 10%, rgba(0,230,118,.06) 0%, transparent 60%),
        radial-gradient(ellipse 60% 80% at 80% 90%, rgba(0,100,255,.08) 0%, transparent 60%);
    pointer-events: none; z-index: 0;
}

/* ── Header ── */
header {
    position: relative; z-index: 1;
    display: flex; align-items: center; gap: 18px;
    padding: 32px 40px 24px;
    border-bottom: 1px solid var(--border);
}

.logo {
    width: 52px; height: 52px;
    background: var(--accent);
    border-radius: 14px;
    display: grid; place-items: center;
    font-size: 26px;
    flex-shrink: 0;
    box-shadow: 0 0 24px rgba(0,230,118,.4);
}

header h1 {
    font-family: 'Bebas Neue', sans-serif;
    font-size: clamp(28px, 4vw, 42px);
    letter-spacing: 2px;
    line-height: 1;
    color: #fff;
}

header p {
    font-size: 13px;
    color: var(--muted);
    margin-top: 4px;
    font-family: var(--mono);
}

.badge {
    margin-left: auto;
    background: rgba(0,230,118,.12);
    border: 1px solid rgba(0,230,118,.3);
    color: var(--accent);
    font-family: var(--mono);
    font-size: 11px;
    padding: 5px 12px;
    border-radius: 99px;
    letter-spacing: .5px;
}

/* ── Main layout ── */
main {
    position: relative; z-index: 1;
    max-width: 1300px;
    margin: 0 auto;
    padding: 36px 40px 60px;
    display: grid;
    gap: 32px;
}

/* ── Stats row ── */
.stats-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
}

.stat-card {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    padding: 20px 22px;
    display: flex; align-items: center; gap: 14px;
    transition: transform .2s, box-shadow .2s;
}
.stat-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 12px 40px rgba(0,0,0,.4);
}

.stat-dot {
    width: 12px; height: 42px;
    border-radius: 6px;
    flex-shrink: 0;
}

.stat-label {
    font-size: 11px;
    color: var(--muted);
    text-transform: uppercase;
    letter-spacing: .8px;
    margin-bottom: 4px;
}

.stat-value {
    font-family: 'Bebas Neue', sans-serif;
    font-size: 28px;
    letter-spacing: 1px;
    color: #fff;
    line-height: 1;
}

.stat-sub {
    font-size: 12px;
    color: var(--muted);
    margin-top: 2px;
}

/* ── Section heading ── */
.section-heading {
    display: flex; align-items: center; gap: 12px;
    margin-bottom: 16px;
}

.section-heading h2 {
    font-family: 'Bebas Neue', sans-serif;
    font-size: 22px;
    letter-spacing: 1.5px;
    color: #fff;
}

.line {
    flex: 1;
    height: 1px;
    background: var(--border);
}

.tag {
    font-family: var(--mono);
    font-size: 10px;
    color: var(--muted);
    background: rgba(255,255,255,.04);
    border: 1px solid var(--border);
    padding: 3px 10px;
    border-radius: 6px;
}

/* ── SQL Code block ── */
.sql-block {
    background: #060d1a;
    border: 1px solid var(--border);
    border-left: 3px solid var(--accent);
    border-radius: var(--radius);
    padding: 20px 24px;
    overflow-x: auto;
}

.sql-block pre {
    font-family: var(--mono);
    font-size: 13px;
    line-height: 1.8;
    color: #c9d8f0;
}

.kw   { color: #82aaff; font-weight: 600; }
.tbl  { color: #c3e88d; }
.col  { color: #ffcb6b; }
.cmt  { color: #546e7a; font-style: italic; }
.str  { color: #f07178; }

/* ── Results table ── */
.table-wrap {
    background: var(--card);
    border: 1px solid var(--border);
    border-radius: var(--radius);
    overflow: hidden;
}

table {
    width: 100%;
    border-collapse: collapse;
    font-size: 14px;
}

thead tr {
    background: rgba(255,255,255,.03);
    border-bottom: 1px solid var(--border);
}

thead th {
    padding: 14px 18px;
    text-align: left;
    font-size: 10px;
    font-weight: 600;
    text-transform: uppercase;
    letter-spacing: 1px;
    color: var(--muted);
    white-space: nowrap;
}

tbody tr {
    border-bottom: 1px solid rgba(255,255,255,.03);
    transition: background .15s;
}

tbody tr:last-child { border-bottom: none; }

tbody tr:hover { background: rgba(255,255,255,.03); }

tbody td {
    padding: 13px 18px;
    color: var(--text);
}

.cell-player {
    display: flex; align-items: center; gap: 10px;
}

.avatar {
    width: 32px; height: 32px;
    border-radius: 50%;
    display: grid; place-items: center;
    font-size: 13px;
    font-weight: 700;
    color: #fff;
    flex-shrink: 0;
    font-family: var(--mono);
}

.player-name  { font-weight: 500; }
.player-pos   { font-size: 11px; color: var(--muted); margin-top: 1px; }

.team-chip {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 4px 10px;
    border-radius: 99px;
    font-size: 12px;
    font-weight: 500;
    background: rgba(255,255,255,.06);
    border: 1px solid var(--border);
}

.team-dot {
    width: 8px; height: 8px;
    border-radius: 50%;
    flex-shrink: 0;
}

.result-chip {
    font-family: var(--mono);
    font-size: 12px;
    font-weight: 600;
    padding: 3px 10px;
    border-radius: 6px;
    background: rgba(0,230,118,.1);
    color: var(--accent);
    border: 1px solid rgba(0,230,118,.2);
}

.date-cell {
    font-family: var(--mono);
    font-size: 12px;
    color: var(--muted);
}

/* ── Empty state ── */
.empty {
    text-align: center;
    padding: 60px 20px;
    color: var(--muted);
    font-size: 14px;
}

/* ── Footer ── */
footer {
    position: relative; z-index: 1;
    text-align: center;
    padding: 24px 40px;
    border-top: 1px solid var(--border);
    font-family: var(--mono);
    font-size: 11px;
    color: var(--muted);
    letter-spacing: .5px;
}

footer span { color: var(--accent); }

/* ── Scrollbar ── */
::-webkit-scrollbar { width: 6px; height: 6px; }
::-webkit-scrollbar-track { background: transparent; }
::-webkit-scrollbar-thumb { background: rgba(255,255,255,.12); border-radius: 3px; }
</style>
</head>
<body>

<header>
    <div class="logo">⚽</div>
    <div>
        <h1>Futbol Klubi Boshqaruvi</h1>
        <p>MySQL › db_futbol &nbsp;·&nbsp; PHP PDO &nbsp;·&nbsp; INNER JOIN</p>
    </div>
    <div class="badge">v2.0 · LIVE</div>
</header>

<main>

    <!-- ── Statistika ── -->
    <div class="stats-grid">
        <?php foreach ($stats as $s): ?>
        <div class="stat-card">
            <div class="stat-dot" style="background:<?= htmlspecialchars($s['rang']) ?>"></div>
            <div>
                <div class="stat-label"><?= htmlspecialchars($s['nomi']) ?></div>
                <div class="stat-value"><?= $s['oyinchilar_soni'] ?> <span style="font-size:16px;color:var(--muted)">o'yinchi</span></div>
                <div class="stat-sub"><?= $s['oyinlar_soni'] ?> o'yin o'ynaldi</div>
            </div>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- ── SQL blok ── -->
    <div>
        <div class="section-heading">
            <h2>JOIN So'rovi</h2>
            <div class="line"></div>
            <div class="tag">SQL</div>
        </div>
        <div class="sql-block">
<pre><span class="cmt">-- O'yinchi + Jamoa + O'yin sanasi (INNER JOIN)</span>
<span class="kw">SELECT</span>
    <span class="tbl">o</span>.<span class="col">ism</span>        <span class="kw">AS</span> oyinchi,
    <span class="tbl">o</span>.<span class="col">pozitsiya</span>  <span class="kw">AS</span> pozitsiya,
    <span class="tbl">j</span>.<span class="col">nomi</span>       <span class="kw">AS</span> jamoa,
    <span class="tbl">oy</span>.<span class="col">sana</span>      <span class="kw">AS</span> sana,
    <span class="tbl">oy</span>.<span class="col">raqib</span>     <span class="kw">AS</span> raqib,
    <span class="tbl">oy</span>.<span class="col">natija</span>    <span class="kw">AS</span> natija
<span class="kw">FROM</span>       <span class="tbl">oyinchilar</span>  <span class="tbl">o</span>
<span class="kw">INNER JOIN</span> <span class="tbl">jamoalar</span>    <span class="tbl">j</span>   <span class="kw">ON</span> <span class="tbl">o</span>.<span class="col">jamoa_id</span>  = <span class="tbl">j</span>.<span class="col">id</span>
<span class="kw">INNER JOIN</span> <span class="tbl">oyinlar</span>     <span class="tbl">oy</span>  <span class="kw">ON</span> <span class="tbl">oy</span>.<span class="col">jamoa_id</span> = <span class="tbl">j</span>.<span class="col">id</span>
<span class="kw">ORDER BY</span>   <span class="tbl">oy</span>.<span class="col">sana</span> <span class="kw">DESC</span>;</pre>
        </div>
    </div>

    <!-- ── Natija jadvali ── -->
    <div>
        <div class="section-heading">
            <h2>Natijalar</h2>
            <div class="line"></div>
            <div class="tag"><?= count($qatorlar) ?> qator</div>
        </div>
        <div class="table-wrap">
            <?php if (empty($qatorlar)): ?>
                <div class="empty">Ma'lumot topilmadi</div>
            <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>O'yinchi</th>
                        <th>Jamoa</th>
                        <th>Raqib</th>
                        <th>Natija</th>
                        <th>O'yin sanasi</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($qatorlar as $i => $q): ?>
                <tr>
                    <td class="date-cell"><?= $i + 1 ?></td>
                    <td>
                        <div class="cell-player">
                            <div class="avatar"
                                 style="background:<?= htmlspecialchars($q['rang']) ?>33;
                                        border:1px solid <?= htmlspecialchars($q['rang']) ?>55">
                                <?= mb_substr($q['oyinchi'], 0, 1) ?>
                            </div>
                            <div>
                                <div class="player-name"><?= htmlspecialchars($q['oyinchi']) ?></div>
                                <div class="player-pos"><?= htmlspecialchars($q['pozitsiya'] ?? '—') ?></div>
                            </div>
                        </div>
                    </td>
                    <td>
                        <div class="team-chip">
                            <div class="team-dot" style="background:<?= htmlspecialchars($q['rang']) ?>"></div>
                            <?= htmlspecialchars($q['jamoa']) ?>
                        </div>
                    </td>
                    <td style="color:var(--muted)"><?= htmlspecialchars($q['raqib'] ?? '—') ?></td>
                    <td>
                        <?php if ($q['natija']): ?>
                        <span class="result-chip"><?= htmlspecialchars($q['natija']) ?></span>
                        <?php else: ?>
                        <span style="color:var(--muted)">—</span>
                        <?php endif; ?>
                    </td>
                    <td class="date-cell">
                        <?= date('d.m.Y', strtotime($q['sana'])) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
    </div>

</main>

<footer>
    <span>db_futbol</span> &nbsp;·&nbsp;
    PHP <?= PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION ?> &nbsp;·&nbsp;
    MySQL PDO &nbsp;·&nbsp;
    INNER JOIN &nbsp;·&nbsp;
    <?= count($qatorlar) ?> natija
</footer>

</body>
</html>