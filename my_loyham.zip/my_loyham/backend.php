<?php
// backend.php - Handles API requests server-side

header('Content-Type: application/json; charset=utf-8');

// Get the type of request
$type = isset($_GET['type']) ? $_GET['type'] : '';

if ($type === 'currency') {
    // URL for Central Bank of Uzbekistan Currency Rates
    $url = 'https://cbu.uz/uz/arkhiv-kursov-valyut/json/';
    
    // Fetch data
    $data = file_get_contents($url);
    
    if ($data === false) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to fetch currency data']);
    } else {
        echo $data;
    }
} elseif ($type === 'weather') {
    // Coordinates for Urgench, Khorezm
    $lat = 41.5564;
    $lon = 60.6314;
    
    // URL for Open-Meteo Weather API
    $url = "https://api.open-meteo.com/v1/forecast?latitude={$lat}&longitude={$lon}&current_weather=true";
    
    // Fetch data
    $data = file_get_contents($url);
    
    if ($data === false) {
        http_response_code(500);
        echo json_encode(['error' => 'Failed to fetch weather data']);
    } else {
        echo $data;
    }
} else {
    // Invalid request type
    http_response_code(400);
    echo json_encode(['error' => 'Invalid request type. Use ?type=currency or ?type=weather']);
}
?>
