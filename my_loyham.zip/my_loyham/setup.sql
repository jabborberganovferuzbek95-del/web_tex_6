-- =============================================
--  setup.sql — Bazani sozlash va demo ma'lumotlar
-- =============================================

CREATE DATABASE IF NOT EXISTS db_futbol
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE db_futbol;

-- Jadval 1: Jamoalar
CREATE TABLE IF NOT EXISTS jamoalar (
    id         INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    nomi       VARCHAR(100)    NOT NULL,
    shahar     VARCHAR(100)    DEFAULT NULL,
    rang       VARCHAR(7)      DEFAULT '#1a56db',  -- HEX rang (UI uchun)
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Jadval 2: Oyinchilar
CREATE TABLE IF NOT EXISTS oyinchilar (
    id         INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    ism        VARCHAR(100)    NOT NULL,
    pozitsiya  VARCHAR(50)     DEFAULT NULL,
    jamoa_id   INT UNSIGNED    NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_oyinchi_jamoa
        FOREIGN KEY (jamoa_id) REFERENCES jamoalar(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Jadval 3: O'yinlar
CREATE TABLE IF NOT EXISTS oyinlar (
    id         INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    jamoa_id   INT UNSIGNED    NOT NULL,
    raqib      VARCHAR(100)    DEFAULT 'Noma''lum',
    sana       DATE            NOT NULL,
    natija     VARCHAR(10)     DEFAULT NULL,   -- '2-1', '0-0' kabi
    PRIMARY KEY (id),
    CONSTRAINT fk_oyin_jamoa
        FOREIGN KEY (jamoa_id) REFERENCES jamoalar(id)
        ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Jadval 4: Foydalanuvchilar (Laboratoriya 10 uchun)
CREATE TABLE IF NOT EXISTS users (
    id         INT UNSIGNED    NOT NULL AUTO_INCREMENT,
    username   VARCHAR(50)     NOT NULL UNIQUE,
    email      VARCHAR(100)    NOT NULL UNIQUE,
    password   VARCHAR(255)    NOT NULL,
    created_at TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- =============================================
--  Demo ma'lumotlar
-- =============================================
INSERT INTO jamoalar (nomi, shahar, rang) VALUES
    ('Pakhtakor',   'Toshkent',    '#007BFF'),
    ('Lokomotiv',   'Toshkent',    '#CC0000'),
    ('AGMK',        'Olmaliq',     '#F5A623'),
    ('Nasaf',       'Qarshi',      '#28A745');

INSERT INTO oyinchilar (ism, pozitsiya, jamoa_id) VALUES
    ('Jasur Yaxshiliqov',  'Hujumchi',     1),
    ('Otabek Shukurov',    'O''rta haker', 1),
    ('Nodir Toshev',       'Himoyachi',    2),
    ('Sherzod Nazarov',    'Darvozabon',   2),
    ('Bobur Mirzayev',     'Hujumchi',     3),
    ('Ulugbek Askarov',    'O''rta haker', 4);

INSERT INTO oyinlar (jamoa_id, raqib, sana, natija) VALUES
    (1, 'AGMK',       '2024-03-10', '3-1'),
    (1, 'Nasaf',      '2024-03-24', '2-0'),
    (2, 'Pakhtakor',  '2024-03-17', '1-2'),
    (2, 'AGMK',       '2024-04-05', '0-0'),
    (3, 'Lokomotiv',  '2024-04-01', '1-1'),
    (4, 'Pakhtakor',  '2024-04-10', '0-3');