<?php
// ============================================
// enrollments.php — Kursga yozilish API
// ============================================

require_once 'config.php';

$pdo    = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$input  = json_decode(file_get_contents('php://input'), true) ?? [];

switch ($method) {

    // ----------------------------------------
    // READ — Barcha yozilishlarni ko'rish
    // ----------------------------------------
    case 'GET':
        $program_id = (int)($_GET['program_id'] ?? 0);
        if ($program_id > 0) {
            $stmt = $pdo->prepare("
                SELECT ce.*, lp.course_title 
                FROM course_enrollments ce 
                JOIN learning_programs lp ON ce.program_id = lp.program_id
                WHERE ce.program_id = ?
                ORDER BY ce.created_at DESC
            ");
            $stmt->execute([$program_id]);
        } else {
            $stmt = $pdo->query("
                SELECT ce.*, lp.course_title 
                FROM course_enrollments ce 
                JOIN learning_programs lp ON ce.program_id = lp.program_id
                ORDER BY ce.created_at DESC
            ");
        }
        $enrollments = $stmt->fetchAll();
        echo json_encode(['success' => true, 'data' => $enrollments, 'count' => count($enrollments)]);
        break;

    // ----------------------------------------
    // CREATE — Kursga yozilish
    // ----------------------------------------
    case 'POST':
        $required = ['program_id', 'student_name', 'student_email'];
        foreach ($required as $field) {
            if (empty($input[$field])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => "$field maydoni to'ldirilishi shart"]);
                exit;
            }
        }

        if (!filter_var($input['student_email'], FILTER_VALIDATE_EMAIL)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'Email manzil noto\'g\'ri']);
            exit;
        }

        // Kurs mavjudligini tekshirish
        $check = $pdo->prepare("SELECT program_id FROM learning_programs WHERE program_id = ?");
        $check->execute([$input['program_id']]);
        if (!$check->fetch()) {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Bunday kurs mavjud emas']);
            exit;
        }

        // Takroriy yozilishni tekshirish
        $dup = $pdo->prepare("SELECT enrollment_id FROM course_enrollments WHERE program_id = ? AND student_email = ?");
        $dup->execute([$input['program_id'], $input['student_email']]);
        if ($dup->fetch()) {
            http_response_code(409);
            echo json_encode(['success' => false, 'message' => 'Siz bu kursga allaqachon yozilgansiz']);
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO course_enrollments (program_id, student_name, student_email, enroll_date)
            VALUES (?, ?, ?, CURDATE())
        ");
        $stmt->execute([
            (int)$input['program_id'],
            trim($input['student_name']),
            strtolower(trim($input['student_email'])),
        ]);

        http_response_code(201);
        echo json_encode(['success' => true, 'message' => 'Kursga muvaffaqiyatli yozildingiz!', 'id' => $pdo->lastInsertId()]);
        break;

    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}