-- ============================================
-- Database: digital_course_db
-- Online Kurslar Platformasi
-- ============================================

CREATE DATABASE IF NOT EXISTS digital_course_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE digital_course_db;

-- ============================================
-- Jadval: learning_programs
-- ============================================
CREATE TABLE IF NOT EXISTS learning_programs (
    program_id      INT AUTO_INCREMENT PRIMARY KEY,
    course_title    VARCHAR(255) NOT NULL,
    instructor_identity VARCHAR(150) NOT NULL,
    duration_hours  INT NOT NULL,
    skill_level     ENUM('Beginner', 'Intermediate', 'Advanced') NOT NULL,
    tuition_fee     DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    publish_date    DATE NOT NULL,
    language_format VARCHAR(100) NOT NULL,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Jadval: course_enrollments
-- ============================================
CREATE TABLE IF NOT EXISTS course_enrollments (
    enrollment_id   INT AUTO_INCREMENT PRIMARY KEY,
    program_id      INT NOT NULL,
    student_name    VARCHAR(150) NOT NULL,
    student_email   VARCHAR(255) NOT NULL,
    enroll_date     DATE NOT NULL DEFAULT (CURRENT_DATE),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (program_id) REFERENCES learning_programs(program_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ============================================
-- Sample Data
-- ============================================
INSERT INTO learning_programs (course_title, instructor_identity, duration_hours, skill_level, tuition_fee, publish_date, language_format) VALUES
('Python Dasturlash Asoslari', 'Jasur Toshmatov', 40, 'Beginner', 299000.00, '2024-01-15', 'O\'zbek'),
('Web Development Full Stack', 'Kamola Yusupova', 120, 'Intermediate', 599000.00, '2024-02-01', 'O\'zbek / Ingliz'),
('Machine Learning va AI', 'Bobur Rahimov', 80, 'Advanced', 899000.00, '2024-02-20', 'Ingliz'),
('React.js Zamonaviy Frontend', 'Nilufar Hasanova', 60, 'Intermediate', 449000.00, '2024-03-05', 'O\'zbek'),
('SQL va Ma\'lumotlar Bazasi', 'Sherzod Mirzayev', 35, 'Beginner', 199000.00, '2024-03-10', 'O\'zbek'),
('Node.js Backend Dasturlash', 'Aziz Karimov', 70, 'Intermediate', 499000.00, '2024-03-25', 'O\'zbek'),
('Kiberxavfsizlik Asoslari', 'Dilnoza Ergasheva', 90, 'Advanced', 749000.00, '2024-04-01', 'Ingliz'),
('Flutter Mobile App', 'Farrux Nazarov', 55, 'Beginner', 379000.00, '2024-04-15', 'O\'zbek');