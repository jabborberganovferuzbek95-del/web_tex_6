<?php
// ============================================
// courses.php — Kurslar CRUD API
// ============================================

require_once 'config.php';

$pdo    = getDBConnection();
$method = $_SERVER['REQUEST_METHOD'];
$input  = json_decode(file_get_contents('php://input'), true) ?? [];

// URL dan action va id olish
$action = $_GET['action'] ?? '';
$id     = (int)($_GET['id'] ?? 0);

switch ($method) {

    // ----------------------------------------
    // READ — Barcha kurslarni olish
    // ----------------------------------------
    case 'GET':
        if ($action === 'single' && $id > 0) {
            $stmt = $pdo->prepare("SELECT * FROM learning_programs WHERE program_id = ?");
            $stmt->execute([$id]);
            $course = $stmt->fetch();
            if ($course) {
                echo json_encode(['success' => true, 'data' => $course]);
            } else {
                http_response_code(404);
                echo json_encode(['success' => false, 'message' => 'Kurs topilmadi']);
            }
        } else {
            // Filter, sort, search
            $where    = [];
            $params   = [];

            if (!empty($_GET['skill_level'])) {
                $where[]  = "skill_level = ?";
                $params[] = $_GET['skill_level'];
            }
            if (!empty($_GET['search'])) {
                $where[]  = "course_title LIKE ?";
                $params[] = '%' . $_GET['search'] . '%';
            }

            $whereSQL = $where ? 'WHERE ' . implode(' AND ', $where) : '';
            $orderSQL = 'ORDER BY program_id DESC';

            if (!empty($_GET['sort'])) {
                switch ($_GET['sort']) {
                    case 'price_asc':   $orderSQL = 'ORDER BY tuition_fee ASC';   break;
                    case 'price_desc':  $orderSQL = 'ORDER BY tuition_fee DESC';  break;
                    case 'newest':      $orderSQL = 'ORDER BY publish_date DESC';  break;
                    case 'oldest':      $orderSQL = 'ORDER BY publish_date ASC';   break;
                }
            }

            $stmt = $pdo->prepare("SELECT * FROM learning_programs $whereSQL $orderSQL");
            $stmt->execute($params);
            $courses = $stmt->fetchAll();

            // Enrollment count
            foreach ($courses as &$course) {
                $s = $pdo->prepare("SELECT COUNT(*) as cnt FROM course_enrollments WHERE program_id = ?");
                $s->execute([$course['program_id']]);
                $course['enrollment_count'] = (int)$s->fetch()['cnt'];
            }

            echo json_encode(['success' => true, 'data' => $courses, 'count' => count($courses)]);
        }
        break;

    // ----------------------------------------
    // CREATE — Yangi kurs qo'shish
    // ----------------------------------------
    case 'POST':
        $required = ['course_title', 'instructor_identity', 'duration_hours', 'skill_level', 'tuition_fee', 'publish_date', 'language_format'];
        foreach ($required as $field) {
            if (empty($input[$field])) {
                http_response_code(400);
                echo json_encode(['success' => false, 'message' => "$field maydoni to'ldirilishi shart"]);
                exit;
            }
        }

        $validLevels = ['Beginner', 'Intermediate', 'Advanced'];
        if (!in_array($input['skill_level'], $validLevels)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'skill_level noto\'g\'ri qiymat']);
            exit;
        }

        $stmt = $pdo->prepare("
            INSERT INTO learning_programs 
            (course_title, instructor_identity, duration_hours, skill_level, tuition_fee, publish_date, language_format)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            trim($input['course_title']),
            trim($input['instructor_identity']),
            (int)$input['duration_hours'],
            $input['skill_level'],
            (float)$input['tuition_fee'],
            $input['publish_date'],
            trim($input['language_format']),
        ]);

        $newId = $pdo->lastInsertId();
        http_response_code(201);
        echo json_encode(['success' => true, 'message' => 'Kurs muvaffaqiyatli qo\'shildi', 'id' => $newId]);
        break;

    // ----------------------------------------
    // UPDATE — Kurs ma'lumotlarini tahrirlash
    // ----------------------------------------
    case 'PUT':
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID ko\'rsatilmagan']);
            exit;
        }

        $fields = [];
        $params = [];
        $allowed = ['course_title', 'instructor_identity', 'duration_hours', 'skill_level', 'tuition_fee', 'publish_date', 'language_format'];

        foreach ($allowed as $field) {
            if (isset($input[$field])) {
                $fields[] = "$field = ?";
                $params[] = $input[$field];
            }
        }

        if (empty($fields)) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'O\'zgartiriladigan maydon yo\'q']);
            exit;
        }

        $params[] = $id;
        $stmt = $pdo->prepare("UPDATE learning_programs SET " . implode(', ', $fields) . " WHERE program_id = ?");
        $stmt->execute($params);

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Kurs muvaffaqiyatli yangilandi']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Kurs topilmadi yoki o\'zgartirish yo\'q']);
        }
        break;

    // ----------------------------------------
    // DELETE — Kursni o'chirish
    // ----------------------------------------
    case 'DELETE':
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(['success' => false, 'message' => 'ID ko\'rsatilmagan']);
            exit;
        }

        $stmt = $pdo->prepare("DELETE FROM learning_programs WHERE program_id = ?");
        $stmt->execute([$id]);

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => true, 'message' => 'Kurs muvaffaqiyatli o\'chirildi']);
        } else {
            http_response_code(404);
            echo json_encode(['success' => false, 'message' => 'Kurs topilmadi']);
        }
        break;

    default:
        http_response_code(405);
        echo json_encode(['success' => false, 'message' => 'Method not allowed']);
}