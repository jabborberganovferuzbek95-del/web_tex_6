<?php
// ─── Ma'lumotlar bazasi sozlamalari ───
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // MySQL foydalanuvchi nomi
define('DB_PASS', 'feruzbek3437');           // MySQL paroli (XAMPP da odatda bo'sh)
define('DB_NAME', 'talim_db');
define('DB_CHARSET', 'utf8mb4');

// ─── Ulanish ───
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'Baza ulanish xatosi: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}

// ─── CORS & JSON headers ───
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}
