<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$pdo    = getDB();

// ─── GET — barcha fanlar (o'qituvchi ismi bilan) ───
if ($method === 'GET') {
    $stmt = $pdo->query("
        SELECT f.*, o.ism AS oqituvchi_ism, o.daraja AS oqituvchi_daraja
        FROM fanlar f
        LEFT JOIN oqituvchilar o ON f.oqituvchi_id = o.id
        ORDER BY f.id DESC
    ");
    echo json_encode($stmt->fetchAll());
}

// ─── POST — yangi fan qo'shish ───
elseif ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['nomi']) || empty($data['kredit']) || empty($data['oqituvchi_id'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Barcha maydonlar to\'ldirilishi shart']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO fanlar (nomi, kredit, oqituvchi_id) VALUES (?, ?, ?)");
    $stmt->execute([
        trim($data['nomi']),
        (int)$data['kredit'],
        (int)$data['oqituvchi_id']
    ]);

    $id = $pdo->lastInsertId();
    $row = $pdo->query("
        SELECT f.*, o.ism AS oqituvchi_ism
        FROM fanlar f
        LEFT JOIN oqituvchilar o ON f.oqituvchi_id = o.id
        WHERE f.id = $id
    ")->fetch();
    http_response_code(201);
    echo json_encode($row);
}

// ─── DELETE — fanni o'chirish ───
elseif ($method === 'DELETE') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'ID kiritilmadi']);
        exit;
    }
    $stmt = $pdo->prepare("DELETE FROM fanlar WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(['success' => true, 'id' => $id]);
}

else {
    http_response_code(405);
    echo json_encode(['error' => 'Metod qo\'llab-quvvatlanmaydi']);
}
