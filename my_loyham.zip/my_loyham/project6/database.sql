-- =============================================
--  Ta'lim Bazasi — MySQL Setup
--  Faylni phpMyAdmin yoki MySQL CLI da ishga tushiring
-- =============================================

CREATE DATABASE IF NOT EXISTS talim_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE talim_db;

-- O'qituvchilar jadvali
CREATE TABLE IF NOT EXISTS oqituvchilar (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    ism        VARCHAR(100) NOT NULL,
    daraja     VARCHAR(50)  NOT NULL,
    tajriba    INT          NOT NULL DEFAULT 0,
    yaratilgan TIMESTAMP    DEFAULT CURRENT_TIMESTAMP
);

-- Fanlar jadvali
CREATE TABLE IF NOT EXISTS fanlar (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    nomi         VARCHAR(100) NOT NULL,
    kredit       INT          NOT NULL DEFAULT 1,
    oqituvchi_id INT          NOT NULL,
    yaratilgan   TIMESTAMP    DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (oqituvchi_id) REFERENCES oqituvchilar(id) ON DELETE CASCADE
);

-- Namuna ma'lumotlar (ixtiyoriy)
-- INSERT INTO oqituvchilar (ism, daraja, tajriba) VALUES ('Alisher Karimov', 'Professor', 15);
-- INSERT INTO fanlar (nomi, kredit, oqituvchi_id) VALUES ('Matematika', 3, 1);
