<?php
require_once 'config.php';

$method = $_SERVER['REQUEST_METHOD'];
$pdo    = getDB();

// ─── GET — barcha o'qituvchilar ───
if ($method === 'GET') {
    $stmt = $pdo->query("SELECT * FROM oqituvchilar ORDER BY id DESC");
    echo json_encode($stmt->fetchAll());
}

// ─── POST — yangi o'qituvchi qo'shish ───
elseif ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (empty($data['ism']) || empty($data['daraja']) || !isset($data['tajriba'])) {
        http_response_code(400);
        echo json_encode(['error' => 'Barcha maydonlar to\'ldirilishi shart']);
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO oqituvchilar (ism, daraja, tajriba) VALUES (?, ?, ?)");
    $stmt->execute([
        trim($data['ism']),
        trim($data['daraja']),
        (int)$data['tajriba']
    ]);

    $id = $pdo->lastInsertId();
    $row = $pdo->query("SELECT * FROM oqituvchilar WHERE id = $id")->fetch();
    http_response_code(201);
    echo json_encode($row);
}

// ─── DELETE — o'qituvchini o'chirish ───
elseif ($method === 'DELETE') {
    $id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
    if (!$id) {
        http_response_code(400);
        echo json_encode(['error' => 'ID kiritilmadi']);
        exit;
    }
    // CASCADE tufayli bog'liq fanlar ham o'chadi
    $stmt = $pdo->prepare("DELETE FROM oqituvchilar WHERE id = ?");
    $stmt->execute([$id]);
    echo json_encode(['success' => true, 'id' => $id]);
}

else {
    http_response_code(405);
    echo json_encode(['error' => 'Metod qo\'llab-quvvatlanmaydi']);
}
