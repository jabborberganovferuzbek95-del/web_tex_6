<?php
require_once 'db.php';

try {
    $conn = getConnection();
    
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id         INT UNSIGNED    NOT NULL AUTO_INCREMENT,
        username   VARCHAR(50)     NOT NULL UNIQUE,
        email      VARCHAR(100)    NOT NULL UNIQUE,
        password   VARCHAR(255)    NOT NULL,
        created_at TIMESTAMP       DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
    
    $conn->exec($sql);
    echo "Muvaffaqiyatli: 'users' jadvali yaratildi yoki allaqachon mavjud.";
} catch (PDOException $e) {
    echo "Xatolik: " . $e->getMessage();
}
?>
