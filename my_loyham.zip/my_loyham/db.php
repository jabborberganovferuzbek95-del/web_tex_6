<?php
// =============================================
//  db.php — PDO ulanish va yordamchi funksiyalar
// =============================================

define('DB_HOST', 'localhost');
define('DB_NAME', 'db_futbol');
define('DB_USER', 'root');
define('DB_PASS', 'feruzbek3437');
define('DB_CHAR', 'utf8mb4');

function getConnection(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $dsn = sprintf(
            'mysql:host=%s;dbname=%s;charset=%s',
            DB_HOST, DB_NAME, DB_CHAR
        );
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        try {
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            http_response_code(500);
            die(json_encode(['error' => 'DB ulanish xatoligi: ' . $e->getMessage()]));
        }
    }
    return $pdo;
}