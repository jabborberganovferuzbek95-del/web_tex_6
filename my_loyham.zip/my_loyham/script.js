// ===========================================
// LOYIHALAR MA'LUMOTLARI
// ===========================================
const projects = [
    {
        id: 1,
        title: "Laboratoriya_1",
        description: "AJAX so'rovlari yuborish va javobni ishlash uchun veb-ilova",
        icon: "",
        tags: ["", "", ""],
        type: "html"
    },
    {
        id: 2,
        title: "Laboratoriya_2",
        description: "PHP dasturlash tilida oddiy skript yozish va HTML forma ma'lumotlarini qabul qilish",
        icon: "",
        tags: ["", "", ""],
        type: "php",
        filename: "project2.php"
    },
    {
        id: 3,
        title: "Laboratoriya_3",
        description: "PHP da Massivlar va Funksiyalar bilan Ishlash",
        icon: "",
        tags: ["", "", ""],
        type: "php",
        filename: "project3.php"
    },
    {
        id: 4,
        title: "Laboratoriya_4",
        description: "PHP orqali MySQL ma’lumotlar bazasiga ulanish",
        icon: "",
        tags: ["", "", ""],
        type: "php",
        filename: "project4.php"

    },
    {
        id: 5,
        title: "Laboratoriya_5",
        description: "PHP orqali CRUD (Create, Read, Update, Delete) amallarini bajarish",
        icon: "",
        tags: ["", "", ""],
        type: "",
        filename: "project5/index.html"
    },
    {
        id: 6,
        title: "Laboratoriya_6",
        description: "MySQL da jadval yaratish va so'rov yuborish ",
        icon: "chat",
        tags: ["", "", ""],
        type: "html",
        filename: "project6/index.html"
    },
    {
        id: 7,
        title: "Laboratoriya 7",
        description: "PHP da sessiya va cookielar bilan ishlash",
        icon: "",
        tags: ["", "", ""],
        type: "html",
        filename:"project7.html"
    },
    {
        id: 8,
        title: "Laboratoriya 8",
        description: "PHP orqali fayl yuklash va saqlash moduli",
        icon: "",
        tags: ["", "", ""],
        type: "php",
        filename: "project8/index.php"
    },
    {
        id: 9,
        title: "Laboratoriya_9",
        description: "CAPTCHA yaratish va formaga integratsiya qilish",
        icon: "",
        tags: ["", "", ""],
        type: "html",
        filename: "project9.html"
    },
    {
        id: 10,
        title: "Laboratoriya_10",
        description: "Bootstrap yordamida adaptiv sahifa yaratish",
        icon: "",
        tags: ["", "", ""],
        type: "php",
        filename: "project10.php"
    },
    {
        id: 11,
        title: "Photo Gallery",
        description: "Chiroyli fotogalereya. Masonry layout va lightbox effektlari.",
        icon: "photo",
        tags: ["Grid", "UI", "Web"],
        type: "html"
    },
    {
        id: 12,
        title: "Quiz Ilovasi",
        description: "Interaktiv test topshirish platformasi. Natijalarni tahlil qilish va statistika.",
        icon: "quiz",
        tags: ["Logic", "Edu", "App"],
        type: "html"
    },
    {
        id: 13,
        title: "Booking Tizimi",
        description: "Onlayn bronlash tizimi. Kalendar integratsiyasi va to'lov qabul qilish.",
        icon: "book",
        tags: ["DB", "Auth", "B2B"],
        type: "php"  // PHP loyiha misoli
    },
    {
        id: 14,
        title: "Social Media Dashboard",
        description: "Ijtimoiy tarmoqlar analytics platformasi. Grafiklar va statistik ma'lumotlar.",
        icon: "social",
        tags: ["Data", "API", "App"],
        type: "html"
    },
    {
        id: 15,
        title: "Online Learning Platform",
        description: "Onlayn ta'lim platformasi. Video darslar, testlar va sertifikatlar tizimi.",
        icon: "learn",
        tags: ["Edu", "Video", "LMS"],
        type: "html"
    },
    {
        id: 16,
        title: "DOCX O'quvchi",
        description: "Brauzerda DOCX fayllarni ochish va matnini ko'rish imkoniyati.",
        icon: "docx",
        tags: ["File", "Lib", "Web"],
        filename: "project16.html"  // to'liq filename berildi
    }
];

// ===========================================
// LOYIHA LINKINI ANIQLASH FUNKSIYASI
// ===========================================
function getProjectLink(project) {
    // Agar to'liq filename berilgan bo'lsa, shuni ishlatamiz
    if (project.filename) {
        return project.filename;
    }
    // Aks holda type asosida kengaytma tanlaymiz (default: html)
    const ext = project.type || "html";
    return `project${project.id}.${ext}`;
}

// ===========================================
// SVG IKONALAR
// ===========================================
const projectIcons = {
    ajax: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>`,
    php: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/></svg>`,
    blog: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><path d="M12 11l-8-5"/><path d="M12 11l8-5"/><path d="M4 18l8-7 8 7"/></svg>`,
    todo: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 01-2 2H5a2 2 0 01-2-2V5a2 2 0 012-2h11"/></svg>`,
    weather: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2v2"/><path d="M12 20v2"/><path d="M4.93 4.93l1.41 1.41"/><path d="M17.66 17.66l1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="M4.93 19.07l1.41-1.41"/><path d="M17.66 6.34l1.41-1.41"/><circle cx="12" cy="12" r="4"/></svg>`,
    chat: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z"/></svg>`,
    food: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 20l4-4"/><path d="M12 2v2"/><path d="M5 21v-16a2 2 0 012-2h10a2 2 0 012 2v16"/><path d="M9 7h6"/><path d="M9 11h6"/><path d="M9 15h6"/></svg>`,
    page: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><path d="M3 9h18"/><path d="M9 21V9"/></svg>`,
    music: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg>`,
    task: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 5v14M5 12h14"/></svg>`,
    photo: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>`,
    quiz: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>`,
    book: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M4 19.5A2.5 2.5 0 016.5 17H20"/><path d="M4 4.5A2.5 2.5 0 016.5 2H20v20H6.5a2.5 2.5 0 01-2.5-2.5V4.5z"/></svg>`,
    social: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 8a3 3 0 00-3-3H5a3 3 0 00-3 3v8a3 3 0 003 3h10a3 3 0 003-3V8z"/><path d="M22 12c-3.5 0-3.5 10 0 10V12z"/></svg>`,
    learn: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M22 10v6M2 10l10-5 10 5-10 5z"/><path d="M6 12v5c3 3 9 3 12 0v-5"/></svg>`,
    docx: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><path d="M14 2v6h6"/><path d="M8 13h8"/><path d="M8 17h8"/><path d="M10 9H8"/></svg>`
};

// ===========================================
// LOYIHALAR KARTALARINI GENERATSIYA QILISH
// ===========================================
function generateProjectCards() {
    const projectsGrid = document.querySelector('.projects-grid');

    if (!projectsGrid) return;

    projectsGrid.innerHTML = '';

    projects.forEach((project, index) => {
        const card = document.createElement('div');
        card.className = 'project-card';
        card.style.animationDelay = `${index * 0.1}s`;

        const colorIndex = (index % 6) + 1;
        const rgbs = ['99, 102, 241', '139, 92, 246', '217, 70, 239', '236, 72, 153', '244, 63, 94', '239, 68, 68'];
        card.style.setProperty('--p-color', `var(--clr-${colorIndex})`);
        card.style.setProperty('--p-rgb', rgbs[colorIndex - 1]);

        const iconSvg = projectIcons[project.icon] || projectIcons.task;
        const tagsHtml = project.tags.map(tag =>
            `<span class="project-tag" style="--primary-color: var(--clr-${colorIndex}); background: rgba(var(--p-rgb), 0.05); border-color: rgba(var(--p-rgb), 0.1); color: var(--clr-${colorIndex});">${tag}</span>`
        ).join('');

        // ✅ Asosiy o'zgarish: link funksiya orqali aniqlanadi
        const projectLink = getProjectLink(project);

        // Kengaytmani badge sifatida ko'rsatish
        const ext = projectLink.split('.').pop().toUpperCase();
        const extColor = ext === 'PHP' ? '#8b5cf6' : '#3b82f6';

        card.innerHTML = `
            <div class="project-header">
                <div class="project-icon-wrapper">
                    ${iconSvg}
                </div>
                <div style="display:flex; align-items:center; gap:6px;">
                    <span style="font-size:10px; font-weight:700; padding:2px 7px; border-radius:20px; background:${extColor}22; color:${extColor}; border:1px solid ${extColor}44; letter-spacing:0.5px;">${ext}</span>
                    <div class="project-number">${String(project.id).padStart(2, '0')}</div>
                </div>
            </div>
            <div class="project-content">
                <h3 class="project-title">${project.title}</h3>
                <p class="project-description">${project.description}</p>
                <div class="project-tags">
                    ${tagsHtml}
                </div>
                <div class="project-footer">
                    <a href="${projectLink}" class="project-link">
                        <span>Loyihani ko'rish</span>
                    </a>
                </div>
            </div>
            <div class="card-glow"></div>
        `;

        // Kartaga bosish — link tugmasiga bosilmagan joyda ham ishlaydi
        card.addEventListener('click', function (e) {
            if (!e.target.closest('.project-link')) {
                window.location.href = projectLink;
            }
        });

        projectsGrid.appendChild(card);
    });
}

// ===========================================
// SMOOTH SCROLL NAVIGATSIYA
// ===========================================
function initSmoothScroll() {
    const navLinks = document.querySelectorAll('.nav-link');

    navLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            const href = this.getAttribute('href');

            if (href.startsWith('#')) {
                e.preventDefault();

                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);

                if (targetElement) {
                    navLinks.forEach(l => l.classList.remove('active'));
                    this.classList.add('active');

                    const offsetTop = targetElement.offsetTop - 80;
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

// ===========================================
// SCROLL ANIMATSIYALARI (AOS)
// ===========================================
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('aos-animate');
            }
        });
    }, observerOptions);

    document.querySelectorAll('[data-aos]').forEach(el => {
        observer.observe(el);
    });
}

// ===========================================
// NAVBAR SCROLL EFFEKTI
// ===========================================
function initNavbarScroll() {
    const navbar = document.querySelector('.navbar');
    let lastScroll = 0;

    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;

        if (currentScroll > 100) {
            navbar.style.boxShadow = '0 2px 12px rgba(0, 0, 0, 0.08)';
        } else {
            navbar.style.boxShadow = 'none';
        }

        lastScroll = currentScroll;
    });
}

// ===========================================
// ACTIVE NAV LINK AVTOMATIK YANGILASH
// ===========================================
function updateActiveNavLink() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');

    window.addEventListener('scroll', () => {
        let current = '';

        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.clientHeight;

            if (window.pageYOffset >= sectionTop &&
                window.pageYOffset < sectionTop + sectionHeight) {
                current = section.getAttribute('id');
            }
        });

        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

// ===========================================
// PROFIL RASMINI YUKLASH (opsional)
// ===========================================
function initProfileImageUpload() {
    const profileImg = document.getElementById('profileImg');

    if (profileImg) {
        profileImg.addEventListener('dblclick', function () {
            const newImageUrl = prompt('Yangi rasm URL manzilini kiriting:');
            if (newImageUrl) {
                this.src = newImageUrl;
            }
        });
    }
}

// ===========================================
// LOADER (sahifa yuklanayotganda)
// ===========================================
function hideLoader() {
    window.addEventListener('load', () => {
        document.body.style.opacity = '0';
        setTimeout(() => {
            document.body.style.transition = 'opacity 0.5s ease';
            document.body.style.opacity = '1';
        }, 100);
    });
}

// ===========================================
// DYNAMIC GLOW EFFEKT
// ===========================================
function initCardGlow() {
    const cards = document.querySelectorAll('.project-card');

    cards.forEach(card => {
        card.addEventListener('mousemove', e => {
            const rect = card.getBoundingClientRect();
            const x = ((e.clientX - rect.left) / card.clientWidth) * 100;
            const y = ((e.clientY - rect.top) / card.clientHeight) * 100;

            card.style.setProperty('--x', `${x}%`);
            card.style.setProperty('--y', `${y}%`);
        });
    });
}

// ===========================================
// BARCHA FUNKSIYALARNI ISHGA TUSHIRISH
// ===========================================
document.addEventListener('DOMContentLoaded', () => {
    generateProjectCards();
    initSmoothScroll();
    initScrollAnimations();
    initNavbarScroll();
    updateActiveNavLink();
    initProfileImageUpload();
    hideLoader();
    initCardGlow();

    console.log('🚀 Portfolio web-sayti muvaffaqiyatli yuklandi!');
    console.log(`📊 Jami loyihalar: ${projects.length}`);
});

// ===========================================
// EXPORT (agar kerak bo'lsa)
// ===========================================
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { projects, getProjectLink };
}