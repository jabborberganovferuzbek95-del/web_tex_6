// ===========================================
// LOYIHALAR MA'LUMOTLARI
// ===========================================
const projects = [
    {
        id: 1,
        title: "Laboratoriya_1",
        description: "AJAX so‘rovlari yuborish va javobni ishlash uchun veb-ilova"
    },
    {
        id: 2,
        title: "Laboratoriya_2",
        description: "PHP dasturlash tilida oddiy skript yozish va HTML forma ma’lumotlarini qabul qilish"
    },
    {
        id: 3,
        title: "Blog Platformasi",
        description: "Kuchli blog yozish va boshqarish tizimi. Markdown qo'llab-quvvatlash va SEO optimizatsiya."
    },
    {
        id: 4,
        title: "To-Do List Ilovasi",
        description: "Vazifalarni boshqarish uchun qulay ilova. Drag-and-drop va prioritetlar tizimi."
    },
    {
        id: 5,
        title: "Weather Dashboard",
        description: "Ob-havo ma'lumotlarini ko'rsatuvchi interaktiv dashboard. Real-time yangilanishlar."
    },
    {
        id: 6,
        title: "Chat Ilovasi",
        description: "Real-time chat ilovasi. WebSocket texnologiyasi va guruh chat imkoniyati."
    },
    {
        id: 7,
        title: "Restoran Menyusi",
        description: "Interaktiv restoran menyusi. Buyurtma berish va to'lov tizimi integratsiyasi."
    },
    {
        id: 8,
        title: "Landing Page Generator",
        description: "Landing page yaratish uchun qulay vosita. Drag-and-drop interfeys."
    },
    {
        id: 9,
        title: "Music Player",
        description: "Zamonaviy musiqa pleyer. Playlist yaratish va audio vizualizatsiya."
    },
    {
        id: 10,
        title: "Task Management System",
        description: "Jamoaviy ishlash uchun vazifalar boshqaruv tizimi. Kanban board va timeline view."
    },
    {
        id: 11,
        title: "Photo Gallery",
        description: "Chiroyli fotogalereya. Masonry layout va lightbox effektlari."
    },
    {
        id: 12,
        title: "Quiz Ilovasi",
        description: "Interaktiv test topshirish platformasi. Natijalarni tahlil qilish va statistika."
    },
    {
        id: 13,
        title: "Booking Tizimi",
        description: "Onlayn bronlash tizimi. Kalendar integratsiyasi va to'lov qabul qilish."
    },
    {
        id: 14,
        title: "Social Media Dashboard",
        description: "Ijtimoiy tarmoqlar analytics platformasi. Grafiklar va statistik ma'lumotlar."
    },
    {
        id: 15,
        title: "Online Learning Platform",
        description: "Onlayn ta'lim platformasi. Video darslar, testlar va sertifikatlar tizimi."
    }
];

// ===========================================
// LOYIHALAR KARTALARINI GENERATSIYA QILISH
// ===========================================
function generateProjectCards() {
    const projectsGrid = document.querySelector('.projects-grid');
    
    if (!projectsGrid) return;
    
    projectsGrid.innerHTML = '';
    
    projects.forEach((project, index) => {
        const card = document.createElement('div');
        card.className = 'project-card';
        // Har bir karta uchun kichik animatsiya kechikishi
        card.style.animationDelay = `${index * 0.1}s`;
        
        card.innerHTML = `
            <div class="project-number">${String(project.id).padStart(2, '0')}</div>
            <div class="project-content">
                <h3 class="project-title">${project.title}</h3>
                <p class="project-description">${project.description}</p>
                <a href="project${project.id}.html" class="project-link">
                    Loyihani ko'rish
                </a>
            </div>
        `;
        
        // Kartaga bosish hodisasi
        card.addEventListener('click', function(e) {
            // Agar link bosilmagan bo'lsa, kartaning o'ziga bosish
            if (!e.target.classList.contains('project-link')) {
                window.location.href = `project${project.id}.html`;
            }
        });
        
        projectsGrid.appendChild(card);
    });
}

// ===========================================
// SMOOTH SCROLL NAVIGATSIYA
// ===========================================
function initSmoothScroll() {
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            
            // Faqat anchor linklar uchun
            if (href.startsWith('#')) {
                e.preventDefault();
                
                const targetId = href.substring(1);
                const targetElement = document.getElementById(targetId);
                
                if (targetElement) {
                    // Active klassini yangilash
                    navLinks.forEach(l => l.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Smooth scroll
                    const offsetTop = targetElement.offsetTop - 80;
                    window.scrollTo({
                        top: offsetTop,
                        behavior: 'smooth'
                    });
                }
            }
        });
    });
}

// ===========================================
// SCROLL ANIMATSIYALARI (AOS)
// ===========================================
function initScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('aos-animate');
            }
        });
    }, observerOptions);
    
    // Barcha animatsiya elementlarini kuzatish
    document.querySelectorAll('[data-aos]').forEach(el => {
        observer.observe(el);
    });
}

// ===========================================
// NAVBAR SCROLL EFFEKTI
// ===========================================
function initNavbarScroll() {
    const navbar = document.querySelector('.navbar');
    let lastScroll = 0;
    
    window.addEventListener('scroll', () => {
        const currentScroll = window.pageYOffset;
        
        // Scroll pastga - navbar kichik shadow qo'shish
        if (currentScroll > 100) {
            navbar.style.boxShadow = '0 2px 12px rgba(0, 0, 0, 0.08)';
        } else {
            navbar.style.boxShadow = 'none';
        }
        
        lastScroll = currentScroll;
    });
}

// ===========================================
// ACTIVE NAV LINK AVTOMATIK YANGILASH
// ===========================================
function updateActiveNavLink() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');
    
    window.addEventListener('scroll', () => {
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop - 100;
            const sectionHeight = section.clientHeight;
            
            if (window.pageYOffset >= sectionTop && 
                window.pageYOffset < sectionTop + sectionHeight) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });
}

// ===========================================
// PROFIL RASMINI YUKLASH (opsional)
// ===========================================
function initProfileImageUpload() {
    const profileImg = document.getElementById('profileImg');
    
    if (profileImg) {
        // Profil rasmiga double-click qilganda rasm o'zgartirish
        // Bu faqat demo uchun, real loyihada file upload bo'lishi kerak
        profileImg.addEventListener('dblclick', function() {
            const newImageUrl = prompt('Yangi rasm URL manzilini kiriting:');
            if (newImageUrl) {
                this.src = newImageUrl;
            }
        });
    }
}

// ===========================================
// PARALLAX EFFEKT (opsional)
// ===========================================
function initParallaxEffect() {
    const hero = document.querySelector('.hero');
    
    if (hero) {
        window.addEventListener('scroll', () => {
            const scrolled = window.pageYOffset;
            const parallaxSpeed = 0.5;
            
            hero.style.transform = `translateY(${scrolled * parallaxSpeed}px)`;
        });
    }
}

// ===========================================
// LOADER (sahifa yuklanayotganda)
// ===========================================
function hideLoader() {
    window.addEventListener('load', () => {
        document.body.style.opacity = '0';
        setTimeout(() => {
            document.body.style.transition = 'opacity 0.5s ease';
            document.body.style.opacity = '1';
        }, 100);
    });
}

// ===========================================
// BARCHA FUNKSIYALARNI ISHGA TUSHIRISH
// ===========================================
document.addEventListener('DOMContentLoaded', () => {
    // Asosiy funksiyalar
    generateProjectCards();
    initSmoothScroll();
    initScrollAnimations();
    initNavbarScroll();
    updateActiveNavLink();
    initProfileImageUpload();
    hideLoader();
    
    // Console log - developer uchun
    console.log('🚀 Portfolio web-sayti muvaffaqiyatli yuklandi!');
    console.log(`📊 Jami loyihalar: ${projects.length}`);
});

// ===========================================
// EXPORT (agar kerak bo'lsa)
// ===========================================
// Boshqa fayllar uchun proyektlar ma'lumotlarini export qilish
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { projects };
}