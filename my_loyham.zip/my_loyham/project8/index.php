<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kreativ Fayl Menejeri</title>
    <!-- Fontlar va Ikonkalar -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #6366f1;
            --danger: #ef4444;
            --success: #10b981;
            --bg: #0f172a;
        }

        body {
            background: var(--bg);
            color: #f8fafc;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            margin: 0;
        }

        .dashboard {
            width: 90%;
            max-width: 800px;
            background: rgba(255, 255, 255, 0.03);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 24px;
            padding: 30px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h2 { font-weight: 300; letter-spacing: 1px; }

        /* Yuklash Formasi */
        .upload-section {
            background: rgba(255, 255, 255, 0.05);
            padding: 20px;
            border-radius: 15px;
            margin-bottom: 30px;
        }

        .input-group { margin-bottom: 15px; }

        input[type="text"] {
            width: 100%;
            padding: 12px;
            background: rgba(0,0,0,0.2);
            border: 1px solid rgba(255,255,255,0.1);
            border-radius: 10px;
            color: white;
            box-sizing: border-box;
        }

        input[type="file"]::-webkit-file-upload-button {
            background: var(--primary);
            border: none;
            padding: 8px 20px;
            border-radius: 8px;
            color: white;
            cursor: pointer;
            margin-right: 15px;
        }

        .btn-upload {
            background: var(--primary);
            color: white;
            border: none;
            padding: 12px 25px;
            border-radius: 10px;
            width: 100%;
            cursor: pointer;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-upload:hover { opacity: 0.8; transform: translateY(-2px); }

        /* Fayllar Ro'yxati */
        .file-list {
            max-height: 300px;
            overflow-y: auto;
        }

        .file-card {
            background: rgba(255, 255, 255, 0.02);
            margin-bottom: 10px;
            padding: 15px;
            border-radius: 12px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border: 1px solid transparent;
            transition: 0.3s;
        }

        .file-card:hover {
            border-color: var(--primary);
            background: rgba(255, 255, 255, 0.05);
        }

        .file-info { display: flex; align-items: center; gap: 15px; }
        .file-info i { font-size: 20px; color: var(--primary); }
        .fio-label { font-size: 12px; color: #94a3b8; display: block; }

        .btn-delete {
            color: var(--danger);
            text-decoration: none;
            width: 35px;
            height: 35px;
            display: flex;
            justify-content: center;
            align-items: center;
            border-radius: 50%;
            background: rgba(239, 68, 68, 0.1);
            transition: 0.3s;
        }

        .btn-delete:hover { background: var(--danger); color: white; }

        .alert {
            padding: 10px;
            border-radius: 10px;
            margin-bottom: 20px;
            text-align: center;
            font-size: 14px;
        }
        .alert-success { background: rgba(16, 185, 129, 0.2); color: var(--success); }
        .alert-error { background: rgba(239, 68, 68, 0.2); color: var(--danger); }
    </style>
</head>
<body>

<div class="dashboard">
    <div class="header">
        <h2><i class="fas fa-cloud-upload-alt"></i> Fayl Moduli</h2>
    </div>

    <!-- Xabarlar -->
    <?php if(isset($_GET['msg'])): ?>
        <div class="alert alert-success"><?= htmlspecialchars($_GET['msg']) ?></div>
    <?php endif; ?>

    <div class="upload-section">
        <form action="handler.php" method="POST" enctype="multipart/form-data">
            <div class="input-group">
                <input type="text" name="fio" placeholder="F.I.O ni kiriting (Masalan: Alisher Valiyev)" required>
            </div>
            <div class="input-group">
                <input type="file" name="user_file" required>
            </div>
            <button type="submit" name="upload" class="btn-upload">
                <i class="fas fa-paper-plane"></i> Faylni Serverga Yuborish
            </button>
        </form>
    </div>

    <div class="file-list">
        <h4 style="margin-bottom: 15px; color: #94a3b8;">Yuklangan hujjatlar:</h4>
        <?php
        $mainDir = 'uploads';
        if (is_dir($mainDir)) {
            $subDirs = array_diff(scandir($mainDir), array('..', '.'));
            foreach ($subDirs as $dir) {
                $dirPath = $mainDir . '/' . $dir;
                if (is_dir($dirPath)) {
                    $files = array_diff(scandir($dirPath), array('..', '.'));
                    foreach ($files as $file) {
                        ?>
                        <div class="file-card">
                            <div class="file-info">
                                <i class="far fa-file-alt"></i>
                                <div>
                                    <span class="fio-label"><?= $dir ?></span>
                                    <span><?= $file ?></span>
                                </div>
                            </div>
                            <a href="handler.php?delete=<?= urlencode($dir.'/'.$file) ?>" class="btn-delete" title="O'chirish">
                                <i class="fas fa-trash-alt"></i>
                            </a>
                        </div>
                        <?php
                    }
                }
            }
        }
        ?>
    </div>
</div>

</body>
</html>