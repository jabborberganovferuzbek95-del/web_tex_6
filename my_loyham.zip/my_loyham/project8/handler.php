<?php
$baseDir = "uploads/";

// FAYL YUKLASH
if (isset($_POST['upload'])) {
    // FIO dagi bo'sh joylarni pastki chiziqqa almashtiramiz (papka nomi xavfsiz bo'lishi uchun)
    $fio = str_replace(' ', '_', trim($_POST['fio']));
    $fio = preg_replace('/[^A-Za-z0-9_\-]/', '', $fio); // Faqat harf va sonlar
    
    $userPath = $baseDir . $fio;

    if (!file_exists($userPath)) {
        mkdir($userPath, 0777, true);
    }

    $fileName = time() . "_" . basename($_FILES["user_file"]["name"]); // Fayl nomini unikal qilish
    $targetFile = $userPath . "/" . $fileName;

    if (move_uploaded_file($_FILES["user_file"]["tmp_name"], $targetFile)) {
        header("Location: index.php?msg=Muvaffaqiyatli saqlandi!");
    } else {
        header("Location: index.php?err=Yuklashda xatolik!");
    }
}

// FAYLNI O'CHIRISH
if (isset($_GET['delete'])) {
    $filePath = $_GET['delete'];
    $fullPath = realpath($baseDir . $filePath);

    // Xavfsizlik tekshiruvi: Fayl haqiqatdan ham uploads ichidami?
    if ($fullPath && strpos($fullPath, realpath($baseDir)) === 0 && file_exists($fullPath)) {
        unlink($fullPath);
        header("Location: index.php?msg=Fayl o'chirildi.");
    } else {
        header("Location: index.php?err=Xatolik: Fayl topilmadi.");
    }
}
?>