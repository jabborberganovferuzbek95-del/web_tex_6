<?php
session_start();
require_once 'db.php';

// Agar allaqachon login qilgan bo'lsa, dashboardga yuboramiz
if (isset($_SESSION['user_id'])) {
    header('Location: project10_dashboard.php');
    exit;
}

$error = '';
$success = '';

// Login yoki Ro'yxatdan o'tishni qayta ishlash
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $conn = getConnection();
    
    // REGISTRATION
    if (isset($_POST['action']) && $_POST['action'] === 'register') {
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $password = $_POST['password'];
        
        if (empty($username) || empty($email) || empty($password)) {
            $error = 'Barcha maydonlarni to\'ldiring!';
        } else {
            // Email yoki username mavjudligini tekshirish
            $stmt = $conn->prepare("SELECT id FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$username, $email]);
            if ($stmt->fetch()) {
                $error = 'Bu username yoki email allaqachon mavjud!';
            } else {
                $hashed_password = password_hash($password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
                if ($stmt->execute([$username, $email, $hashed_password])) {
                    $success = 'Ro\'yxatdan o\'tdingiz! Endi kirishingiz mumkin.';
                } else {
                    $error = 'Xatolik yuz berdi!';
                }
            }
        }
    }
    
    // LOGIN
    if (isset($_POST['action']) && $_POST['action'] === 'login') {
        $login = trim($_POST['login']);
        $password = $_POST['password'];
        
        if (empty($login) || empty($password)) {
            $error = 'Login va parolni kiriting!';
        } else {
            $stmt = $conn->prepare("SELECT * FROM users WHERE username = ? OR email = ?");
            $stmt->execute([$login, $login]);
            $user = $stmt->fetch();
            
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                header('Location: project10_dashboard.php');
                exit;
            } else {
                $error = 'Login yoki parol xato!';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Zamonaviy Kirish va Ro'yxatdan o'tish | Bootstrap 5</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        body {
            font-family: 'Inter', sans-serif;
            background: linear-gradient(135deg, #0f172a 0%, #1e293b 100%);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
            padding: 20px;
        }

        .login-card {
            background: rgba(255, 255, 255, 0.05);
            backdrop-filter: blur(15px);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 24px;
            padding: 40px;
            width: 100%;
            max-width: 450px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
            transition: all 0.3s ease;
        }

        .form-control {
            background: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.1);
            color: #fff !important;
            padding: 12px 15px;
            border-radius: 12px;
        }

        .form-control:focus {
            background: rgba(255, 255, 255, 0.12);
            border-color: #38bdf8;
            box-shadow: 0 0 0 0.25rem rgba(56, 189, 248, 0.25);
        }

        .form-control::placeholder {
            color: #64748b;
        }

        .btn-primary {
            background: linear-gradient(135deg, #38bdf8 0%, #0ea5e9 100%);
            border: none;
            padding: 14px;
            border-radius: 12px;
            font-weight: 600;
            transition: 0.3s;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 20px rgba(56, 189, 248, 0.3);
        }

        .brand-logo {
            font-size: 3rem;
            background: linear-gradient(135deg, #38bdf8 0%, #818cf8 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 20px;
            text-align: center;
        }

        .text-muted-custom {
            color: #94a3b8 !important;
        }

        #registerForm {
            display: none;
        }

        .alert {
            border-radius: 12px;
            border: none;
            background: rgba(255, 255, 255, 0.1);
            color: #fff;
        }
        .alert-danger { background: rgba(239, 68, 68, 0.2); color: #fca5a5; }
        .alert-success { background: rgba(34, 197, 94, 0.2); color: #86efac; }
    </style>
</head>
<body>

<div class="container d-flex justify-content-center">
    <div class="login-card">
        <div class="brand-logo">
            <i class="bi bi-shield-lock-fill"></i>
        </div>

        <!-- Alertlar -->
        <?php if ($error): ?>
            <div class="alert alert-danger mb-4"><i class="bi bi-exclamation-circle me-2"></i><?= $error ?></div>
        <?php endif; ?>
        <?php if ($success): ?>
            <div class="alert alert-success mb-4"><i class="bi bi-check-circle me-2"></i><?= $success ?></div>
        <?php endif; ?>

        <!-- LOGIN FORM -->
        <div id="loginArea">
            <h3 class="text-white text-center mb-2">Kirish</h3>
            <p class="text-muted-custom text-center mb-4">Xush kelibsiz! Davom etish uchun kiring.</p>

            <form method="POST">
                <input type="hidden" name="action" value="login">
                <div class="mb-3">
                    <label class="form-label text-muted-custom">Email yoki Login</label>
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-0 text-white ps-0">
                            <i class="bi bi-person"></i>
                        </span>
                        <input type="text" name="login" class="form-control" placeholder="username yoki mail" required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label text-muted-custom">Parol</label>
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-0 text-white ps-0">
                            <i class="bi bi-key"></i>
                        </span>
                        <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100 mb-3">Kirish</button>
            </form>

            <div class="text-center mt-4">
                <p class="text-muted-custom small">Hisobingiz yo'qmi? <a href="javascript:void(0)" onclick="toggleForms()" class="text-info text-decoration-none fw-bold">Ro'yxatdan o'tish</a></p>
            </div>
        </div>

        <!-- REGISTER FORM -->
        <div id="registerForm">
            <h3 class="text-white text-center mb-2">Ro'yxatdan o'tish</h3>
            <p class="text-muted-custom text-center mb-4">Yangi hisob yaratish uchun ma'lumotlarni kiriting.</p>

            <form method="POST">
                <input type="hidden" name="action" value="register">
                <div class="mb-3">
                    <label class="form-label text-muted-custom">Username</label>
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-0 text-white ps-0">
                            <i class="bi bi-at"></i>
                        </span>
                        <input type="text" name="username" class="form-control" placeholder="foydalanuvchi_nomi" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label text-muted-custom">Email</label>
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-0 text-white ps-0">
                            <i class="bi bi-envelope"></i>
                        </span>
                        <input type="email" name="email" class="form-control" placeholder="mail@example.com" required>
                    </div>
                </div>

                <div class="mb-4">
                    <label class="form-label text-muted-custom">Parol</label>
                    <div class="input-group">
                        <span class="input-group-text bg-transparent border-0 text-white ps-0">
                            <i class="bi bi-shield-lock"></i>
                        </span>
                        <input type="password" name="password" class="form-control" placeholder="••••••••" required>
                    </div>
                </div>

                <button type="submit" class="btn btn-primary w-100 mb-3">Ro'yxatdan o'tish</button>
            </form>

            <div class="text-center mt-4">
                <p class="text-muted-custom small">Hisobingiz bormi? <a href="javascript:void(0)" onclick="toggleForms()" class="text-info text-decoration-none fw-bold">Kirish</a></p>
            </div>
        </div>
    </div>
</div>

<script>
    function toggleForms() {
        const loginArea = document.getElementById('loginArea');
        const registerForm = document.getElementById('registerForm');
        
        if (loginArea.style.display === 'none') {
            loginArea.style.display = 'block';
            registerForm.style.display = 'none';
        } else {
            loginArea.style.display = 'none';
            registerForm.style.display = 'block';
        }
    }
</script>

</body>
</html>
