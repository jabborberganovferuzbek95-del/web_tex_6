<?php
session_start();

// Agar login qilmagan bo'lsa, login sahifasiga qaytaramiz
if (!isset($_SESSION['user_id'])) {
    header('Location: project10.php');
    exit;
}

$username = $_SESSION['username'];
?>
<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard | Galereya</title>
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600&display=swap" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <style>
        :root {
            --bg-dark: #0f172a;
            --card-bg: rgba(255, 255, 255, 0.05);
            --accent: #38bdf8;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: var(--bg-dark);
            color: #fff;
            min-height: 100vh;
        }

        .navbar {
            background: rgba(15, 23, 42, 0.8);
            backdrop-filter: blur(10px);
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .gallery-card {
            background: var(--card-bg);
            border: 1px solid rgba(255, 255, 255, 0.1);
            border-radius: 20px;
            overflow: hidden;
            transition: all 0.3s ease;
            height: 100%;
        }

        .gallery-card:hover {
            transform: translateY(-10px);
            border-color: var(--accent);
            box-shadow: 0 20px 40px rgba(0, 0, 0, 0.4);
        }

        .gallery-img {
            height: 250px;
            width: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .gallery-card:hover .gallery-img {
            transform: scale(1.1);
        }

        .gallery-content {
            padding: 20px;
        }

        .btn-logout {
            background: rgba(239, 68, 68, 0.1);
            color: #fca5a5;
            border: 1px solid rgba(239, 68, 68, 0.2);
            border-radius: 10px;
            padding: 8px 20px;
            transition: 0.3s;
        }

        .btn-logout:hover {
            background: #ef4444;
            color: #fff;
        }

        .welcome-text {
            background: linear-gradient(135deg, #38bdf8 0%, #818cf8 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            font-weight: 700;
        }

        .badge-premium {
            background: rgba(56, 189, 248, 0.2);
            color: var(--accent);
            border: 1px solid rgba(56, 189, 248, 0.3);
            font-size: 0.7rem;
            padding: 4px 10px;
            border-radius: 20px;
        }
    </style>
</head>
<body>

<!-- Navigatsiya -->
<nav class="navbar navbar-expand-lg navbar-dark sticky-top">
    <div class="container">
        <a class="navbar-brand d-flex align-items-center gap-2" href="#">
            <i class="bi bi-grid-1x2-fill text-info"></i>
            <span>Premium Galereya</span>
        </a>
        <div class="d-flex align-items-center gap-3">
            <span class="d-none d-md-inline text-muted">Xush kelibsiz, <strong class="text-white"><?= htmlspecialchars($username) ?></strong></span>
            <a href="logout.php" class="btn-logout text-decoration-none">
                <i class="bi bi-box-arrow-right me-2"></i>Chiqish
            </a>
        </div>
    </div>
</nav>

<!-- Asosiy qism -->
<div class="container py-5">
    <div class="row mb-5 align-items-center">
        <div class="col-md-8">
            <h1 class="display-5 fw-bold mb-2">Mening <span class="welcome-text">Suratlarim</span></h1>
            <p class="text-muted">Siz uchun saralangan eng chiroyli va yuqori sifatli suratlar to'plami.</p>
        </div>
        <div class="col-md-4 text-md-end">
            <span class="badge-premium"><i class="bi bi-star-fill me-1"></i> Premium Foydalanuvchi</span>
        </div>
    </div>

    <!-- Galereya Grid -->
    <div class="row g-4">
        <!-- Rasm 1 (AI Generated) -->
        <div class="col-md-4">
            <div class="gallery-card">
                <div class="overflow-hidden">
                    <img src="images/project10_sample.png" class="gallery-img" alt="Workspace">
                </div>
                <div class="gallery-content">
                    <h5 class="mb-2">Web Workstation</h5>
                    <p class="text-muted small">Zamonaviy dasturchi ish joyi va qulaylik.</p>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="text-info small"><i class="bi bi-calendar3 me-1"></i> 2026-05-08</span>
                        <button class="btn btn-sm btn-outline-info rounded-circle"><i class="bi bi-heart"></i></button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Rasm 2 (Unsplash Placeholder) -->
        <div class="col-md-4">
            <div class="gallery-card">
                <div class="overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&q=80&w=800" class="gallery-img" alt="Digital World">
                </div>
                <div class="gallery-content">
                    <h5 class="mb-2">Digital Connection</h5>
                    <p class="text-muted small">Global tarmoq va texnologiyalar olami.</p>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="text-info small"><i class="bi bi-calendar3 me-1"></i> 2026-05-08</span>
                        <button class="btn btn-sm btn-outline-info rounded-circle"><i class="bi bi-heart"></i></button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Rasm 3 (Unsplash Placeholder) -->
        <div class="col-md-4">
            <div class="gallery-card">
                <div class="overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=800" class="gallery-img" alt="Hardware">
                </div>
                <div class="gallery-content">
                    <h5 class="mb-2">Hardware Evolution</h5>
                    <p class="text-muted small">Kompyuter texnologiyalari va innovatsiyalar.</p>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="text-info small"><i class="bi bi-calendar3 me-1"></i> 2026-05-08</span>
                        <button class="btn btn-sm btn-outline-info rounded-circle"><i class="bi bi-heart"></i></button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Rasm 4 -->
        <div class="col-md-6">
            <div class="gallery-card">
                <div class="overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=1200" class="gallery-img" alt="Analytics">
                </div>
                <div class="gallery-content">
                    <h5 class="mb-2">Data Analytics</h5>
                    <p class="text-muted small">Ma'lumotlarni tahlil qilish va vizualizatsiya.</p>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="text-info small"><i class="bi bi-calendar3 me-1"></i> 2026-05-08</span>
                        <button class="btn btn-sm btn-outline-info rounded-circle"><i class="bi bi-heart"></i></button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Rasm 5 -->
        <div class="col-md-6">
            <div class="gallery-card">
                <div class="overflow-hidden">
                    <img src="https://images.unsplash.com/photo-1518770660439-4636190af475?auto=format&fit=crop&q=80&w=1200" class="gallery-img" alt="Chipset">
                </div>
                <div class="gallery-content">
                    <h5 class="mb-2">Future Silicon</h5>
                    <p class="text-muted small">Mikrosxemalar va kelajak arxitekturasi.</p>
                    <div class="d-flex justify-content-between align-items-center mt-3">
                        <span class="text-info small"><i class="bi bi-calendar3 me-1"></i> 2026-05-08</span>
                        <button class="btn btn-sm btn-outline-info rounded-circle"><i class="bi bi-heart"></i></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Footer -->
<footer class="py-4 mt-5 border-top border-secondary">
    <div class="container text-center text-muted small">
        <p>&copy; 2026 Premium Portfolio System. Barcha huquqlar himoyalangan.</p>
    </div>
</footer>

<!-- Bootstrap 5 JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
