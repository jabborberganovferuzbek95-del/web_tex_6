<!DOCTYPE html>
<html lang="uz">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>3×3 Matritsa</title>
    <link href="https://fonts.googleapis.com/css2?family=Space+Mono:wght@400;700&family=Syne:wght@400;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --bg: #0a0a0f;
            --surface: #111118;
            --border: #1e1e2e;
            --accent: #00ffcc;
            --accent2: #ff3cac;
            --text: #e0e0f0;
            --muted: #555570;
            --cell-bg: #15151f;
        }

        * { margin: 0; padding: 0; box-sizing: border-box; }

        body {
            background: var(--bg);
            color: var(--text);
            font-family: 'Space Mono', monospace;
            min-height: 100vh;
            padding: 2rem 1rem;
        }

        body::before {
            content: '';
            position: fixed;
            inset: 0;
            background-image:
                linear-gradient(var(--border) 1px, transparent 1px),
                linear-gradient(90deg, var(--border) 1px, transparent 1px);
            background-size: 40px 40px;
            opacity: 0.3;
            z-index: 0;
            pointer-events: none;
        }

        .container {
            position: relative;
            z-index: 1;
            max-width: 860px;
            margin: 0 auto;
            display: flex;
            flex-direction: column;
            gap: 1.5rem;
        }

        header {
            text-align: center;
            padding: 0.5rem 0;
        }

        .tag {
            display: inline-block;
            font-size: 0.6rem;
            letter-spacing: 0.25em;
            text-transform: uppercase;
            color: var(--accent);
            border: 1px solid var(--accent);
            padding: 0.25rem 0.75rem;
            border-radius: 2px;
            margin-bottom: 0.75rem;
            box-shadow: 0 0 12px rgba(0,255,204,0.3);
        }

        h1 {
            font-family: 'Syne', sans-serif;
            font-size: clamp(1.8rem, 6vw, 3rem);
            font-weight: 800;
            background: linear-gradient(135deg, #fff 30%, var(--accent) 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            line-height: 1.1;
            margin-bottom: 0.4rem;
        }

        .subtitle {
            color: var(--muted);
            font-size: 0.7rem;
            letter-spacing: 0.1em;
        }

        .card {
            background: var(--surface);
            border: 1px solid var(--border);
            border-radius: 12px;
            padding: 1.5rem;
        }

        .section-title {
            font-size: 0.6rem;
            letter-spacing: 0.2em;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 1.25rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .section-title::after {
            content: '';
            flex: 1;
            height: 1px;
            background: var(--border);
        }

        /* Two column layout for input + matrix */
        .two-col {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1.5rem;
        }

        @media (max-width: 600px) {
            .two-col { grid-template-columns: 1fr; }
        }

        /* INPUT GRID */
        .input-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
            margin-bottom: 1.25rem;
        }

        .input-cell {
            position: relative;
        }

        .input-cell input {
            width: 100%;
            aspect-ratio: 1;
            background: var(--cell-bg);
            border: 1px solid var(--border);
            border-radius: 8px;
            color: var(--text);
            font-family: 'Syne', sans-serif;
            font-size: 1.3rem;
            font-weight: 700;
            text-align: center;
            outline: none;
            transition: border-color 0.2s, box-shadow 0.2s, color 0.2s;
            -moz-appearance: textfield;
        }

        .input-cell input::-webkit-outer-spin-button,
        .input-cell input::-webkit-inner-spin-button { -webkit-appearance: none; }

        .input-cell input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 14px rgba(0,255,204,0.25) inset;
            color: var(--accent);
        }

        .input-cell.is-diag input {
            border-color: rgba(0,255,204,0.6);
            background: rgba(0,255,204,0.05);
            color: var(--accent);
            box-shadow: 0 0 10px rgba(0,255,204,0.15) inset;
        }

        .input-cell .idx {
            position: absolute;
            bottom: 4px;
            right: 6px;
            font-size: 0.45rem;
            color: var(--muted);
            pointer-events: none;
        }

        .input-cell.is-diag .idx { color: rgba(0,255,204,0.4); }

        .input-cell .diag-dot {
            position: absolute;
            top: 5px; right: 5px;
            width: 5px; height: 5px;
            border-radius: 50%;
            background: var(--accent);
            box-shadow: 0 0 6px var(--accent);
            display: none;
        }

        .input-cell.is-diag .diag-dot { display: block; animation: blink 1.5s ease-in-out infinite; }

        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.2} }

        .btn-row {
            display: flex;
            gap: 0.6rem;
            flex-wrap: wrap;
        }

        button {
            font-family: 'Space Mono', monospace;
            font-size: 0.65rem;
            letter-spacing: 0.1em;
            text-transform: uppercase;
            padding: 0.6rem 1.2rem;
            border-radius: 6px;
            border: none;
            cursor: pointer;
            transition: all 0.2s;
        }

        .btn-primary {
            background: var(--accent);
            color: #000;
            font-weight: 700;
        }

        .btn-primary:hover {
            box-shadow: 0 0 20px rgba(0,255,204,0.5);
            transform: translateY(-1px);
        }

        .btn-secondary {
            background: transparent;
            color: var(--muted);
            border: 1px solid var(--border);
        }

        .btn-secondary:hover {
            border-color: var(--muted);
            color: var(--text);
        }

        /* MATRIX DISPLAY */
        .matrix-grid {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 8px;
        }

        .cell {
            aspect-ratio: 1;
            background: var(--cell-bg);
            border: 1px solid var(--border);
            border-radius: 8px;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            position: relative;
            transition: transform 0.2s;
        }

        .cell:hover { transform: scale(1.04); }

        .cell.diagonal {
            border-color: var(--accent);
            background: rgba(0,255,204,0.06);
            animation: diagPulse 2s ease-in-out infinite alternate;
        }

        @keyframes diagPulse {
            from { box-shadow: 0 0 8px rgba(0,255,204,0.12) inset; }
            to { box-shadow: 0 0 22px rgba(0,255,204,0.38) inset; }
        }

        .cell .value {
            font-family: 'Syne', sans-serif;
            font-size: 1.4rem;
            font-weight: 800;
            color: var(--text);
        }

        .cell.diagonal .value {
            color: var(--accent);
            text-shadow: 0 0 10px rgba(0,255,204,0.4);
        }

        .cell .index {
            font-size: 0.45rem;
            color: var(--muted);
            margin-top: 2px;
        }

        .cell.diagonal .index { color: rgba(0,255,204,0.4); }

        .cell .corner-dot {
            position: absolute;
            top: 5px; right: 5px;
            width: 5px; height: 5px;
            border-radius: 50%;
            background: var(--accent);
            display: none;
        }

        .cell.diagonal .corner-dot {
            display: block;
            animation: blink 1.5s ease-in-out infinite;
        }

        /* RESULTS */
        .results-row {
            display: flex;
            gap: 1rem;
            align-items: center;
            flex-wrap: wrap;
        }

        .d-items {
            display: flex;
            gap: 0.75rem;
            align-items: center;
            flex-wrap: wrap;
            flex: 1;
        }

        .d-item {
            background: rgba(0,255,204,0.06);
            border: 1px solid var(--accent);
            border-radius: 8px;
            padding: 0.7rem 1.1rem;
            text-align: center;
        }

        .d-item .d-lbl {
            font-size: 0.48rem;
            letter-spacing: 0.15em;
            text-transform: uppercase;
            color: rgba(0,255,204,0.45);
            margin-bottom: 2px;
        }

        .d-item .d-val {
            font-family: 'Syne', sans-serif;
            font-size: 1.7rem;
            font-weight: 800;
            color: var(--accent);
            text-shadow: 0 0 14px rgba(0,255,204,0.35);
            line-height: 1;
        }

        .arrow { color: var(--muted); }

        .sum-box {
            border-left: 1px solid var(--border);
            padding-left: 1.25rem;
            min-width: 110px;
        }

        .sum-label {
            font-size: 0.52rem;
            letter-spacing: 0.15em;
            text-transform: uppercase;
            color: var(--muted);
            margin-bottom: 4px;
        }

        .sum-val {
            font-family: 'Syne', sans-serif;
            font-size: 2rem;
            font-weight: 800;
            background: linear-gradient(135deg, var(--accent), var(--accent2));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            line-height: 1;
        }

        .legend {
            display: flex;
            gap: 1.25rem;
            margin-top: 1rem;
            font-size: 0.58rem;
            color: var(--muted);
        }

        .legend-item { display: flex; align-items: center; gap: 0.4rem; }
        .ldot { width: 7px; height: 7px; border-radius: 50%; }
        .ldot.d { background: var(--accent); }
        .ldot.n { background: var(--border); border: 1px solid var(--muted); }

        @media (max-width: 500px) {
            .sum-box { border-left: none; border-top: 1px solid var(--border); padding-left: 0; padding-top: 1rem; }
        }
    </style>
</head>
<body>

<?php
$default = [
    [5, 3, 8],
    [2, 7, 4],
    [9, 1, 6]
];

$matrix = $default;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    for ($i = 0; $i < 3; $i++) {
        for ($j = 0; $j < 3; $j++) {
            $val = isset($_POST["m{$i}{$j}"]) ? intval($_POST["m{$i}{$j}"]) : 0;
            $matrix[$i][$j] = $val;
        }
    }
}

$diagonal = [];
for ($i = 0; $i < 3; $i++) {
    $diagonal[] = $matrix[$i][$i];
}
$diagonalSum = array_sum($diagonal);
?>

<div class="container">

    <header>
        <div class="tag">PHP · Linear Algebra</div>
        <h1>3×3 MATRITSA</h1>
        <p class="subtitle">Asosiy diagonal elementlarini topish</p>
    </header>

    <!-- INPUT + MATRIX side by side -->
    <div class="two-col">

        <!-- INPUT FORM -->
        <div class="card">
            <div class="section-title">Qiymatlarni kiriting</div>
            <form method="POST" action="">
                <div class="input-grid">
                    <?php for ($i = 0; $i < 3; $i++): ?>
                        <?php for ($j = 0; $j < 3; $j++): ?>
                            <?php $diag = ($i === $j); ?>
                            <div class="input-cell <?= $diag ? 'is-diag' : '' ?>">
                                <div class="diag-dot"></div>
                                <input
                                    type="number"
                                    name="m<?= $i ?><?= $j ?>"
                                    value="<?= htmlspecialchars($matrix[$i][$j]) ?>"
                                    placeholder="0"
                                >
                                <span class="idx">[<?= $i ?>,<?= $j ?>]</span>
                            </div>
                        <?php endfor; ?>
                    <?php endfor; ?>
                </div>
                <div class="btn-row">
                    <button type="submit" class="btn-primary">▶ Hisoblash</button>
                    <button type="button" class="btn-secondary" onclick="
                        document.querySelectorAll('.input-cell input').forEach(el => el.value = 0);
                    ">↺ Tozalash</button>
                </div>
            </form>
        </div>

        <!-- MATRIX DISPLAY -->
        <div class="card">
            <div class="section-title">Matritsa ko'rinishi</div>
            <div class="matrix-grid">
                <?php for ($i = 0; $i < 3; $i++): ?>
                    <?php for ($j = 0; $j < 3; $j++): ?>
                        <?php $diag = ($i === $j); ?>
                        <div class="cell <?= $diag ? 'diagonal' : '' ?>">
                            <div class="corner-dot"></div>
                            <div class="value"><?= $matrix[$i][$j] ?></div>
                            <div class="index">[<?= $i ?>,<?= $j ?>]</div>
                        </div>
                    <?php endfor; ?>
                <?php endfor; ?>
            </div>
            <div class="legend">
                <div class="legend-item"><div class="ldot d"></div><span>Diagonal (i = j)</span></div>
                <div class="legend-item"><div class="ldot n"></div><span>Oddiy element</span></div>
            </div>
        </div>

    </div>

    <!-- DIAGONAL RESULTS -->
    <div class="card">
        <div class="section-title">Diagonal elementlar natijasi</div>
        <div class="results-row">
            <div class="d-items">
                <?php foreach ($diagonal as $idx => $val): ?>
                    <div class="d-item">
                        <div class="d-lbl">[<?= $idx ?>,<?= $idx ?>]</div>
                        <div class="d-val"><?= $val ?></div>
                    </div>
                    <?php if ($idx < 2): ?>
                        <div class="arrow">+</div>
                    <?php endif; ?>
                <?php endforeach; ?>
            </div>
            <div class="sum-box">
                <div class="sum-label">Diagonal yig'indisi</div>
                <div class="sum-val"><?= $diagonalSum ?></div>
            </div>
        </div>
    </div>

</div>
</body>
</html>